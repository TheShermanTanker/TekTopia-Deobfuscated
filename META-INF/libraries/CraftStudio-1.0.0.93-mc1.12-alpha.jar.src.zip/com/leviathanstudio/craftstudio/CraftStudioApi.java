/*    */ package com.leviathanstudio.craftstudio;
/*    */ 
/*    */ import com.leviathanstudio.craftstudio.common.animation.AnimationHandler;
/*    */ import com.leviathanstudio.craftstudio.proxy.CSCommonProxy;
/*    */ import net.minecraftforge.fml.common.Mod;
/*    */ import net.minecraftforge.fml.common.Mod.EventHandler;
/*    */ import net.minecraftforge.fml.common.SidedProxy;
/*    */ import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
/*    */ import net.minecraftforge.fml.common.network.NetworkRegistry;
/*    */ import net.minecraftforge.fml.common.network.simpleimpl.SimpleNetworkWrapper;
/*    */ import org.apache.logging.log4j.LogManager;
/*    */ import org.apache.logging.log4j.Logger;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Mod(modid = "craftstudioapi", name = "CraftStudio API", updateJSON = "https://leviathan-studio.com/craftstudioapi/update.json", version = "1.0.0", acceptedMinecraftVersions = "1.12")
/*    */ public class CraftStudioApi
/*    */ {
/* 30 */   private static final Logger LOGGER = LogManager.getLogger("CraftStudio");
/*    */   
/*    */   public static final String API_ID = "craftstudioapi";
/*    */   static final String NAME = "CraftStudio API";
/* 34 */   public static final SimpleNetworkWrapper NETWORK = NetworkRegistry.INSTANCE.newSimpleChannel("craftstudioapi");
/*    */   
/*    */   @SidedProxy(clientSide = "com.leviathanstudio.craftstudio.proxy.CSClientProxy", serverSide = "com.leviathanstudio.craftstudio.proxy.CSServerProxy")
/*    */   private static CSCommonProxy proxy;
/*    */   
/*    */   @EventHandler
/*    */   public void preInit(FMLPreInitializationEvent event) {
/* 41 */     proxy.preInit(event);
/*    */   }
/*    */   
/*    */   public static Logger getLogger() {
/* 45 */     return LOGGER;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static <T extends com.leviathanstudio.craftstudio.common.animation.IAnimated> AnimationHandler<T> getNewAnimationHandler(Class<T> animatedClass) {
/* 58 */     return proxy.getNewAnimationHandler(animatedClass);
/*    */   }
/*    */ }


/* Location:              C:\Users\Josep\Downloads\tektopia-1.1.0-deobf.jar!\META-INF\libraries\CraftStudio-1.0.0.93-mc1.12-alpha.jar!\com\leviathanstudio\craftstudio\CraftStudioApi.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */