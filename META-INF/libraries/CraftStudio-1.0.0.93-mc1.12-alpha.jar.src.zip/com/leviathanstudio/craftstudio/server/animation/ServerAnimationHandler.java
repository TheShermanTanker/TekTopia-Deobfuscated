/*     */ package com.leviathanstudio.craftstudio.server.animation;
/*     */ 
/*     */ import com.leviathanstudio.craftstudio.common.animation.AnimationHandler;
/*     */ import com.leviathanstudio.craftstudio.common.animation.Channel;
/*     */ import com.leviathanstudio.craftstudio.common.animation.CustomChannel;
/*     */ import com.leviathanstudio.craftstudio.common.animation.IAnimated;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.WeakHashMap;
/*     */ import net.minecraft.util.ResourceLocation;
/*     */ import net.minecraftforge.fml.relauncher.Side;
/*     */ import net.minecraftforge.fml.relauncher.SideOnly;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @SideOnly(Side.SERVER)
/*     */ public class ServerAnimationHandler<T extends IAnimated>
/*     */   extends AnimationHandler<T>
/*     */ {
/*  34 */   private Map<String, Channel> animChannels = new HashMap<>();
/*     */ 
/*     */   
/*  37 */   private Map<T, Map<String, AnimationHandler.AnimInfo>> currentAnimInfo = new WeakHashMap<>();
/*     */ 
/*     */   
/*  40 */   private Map<T, Map<String, Float>> startingAnimations = new WeakHashMap<>();
/*     */ 
/*     */   
/*     */   public void addAnim(String modid, String animNameIn, String modelNameIn, boolean looped) {
/*  44 */     super.addAnim(modid, animNameIn, modelNameIn, looped);
/*  45 */     ResourceLocation anim = new ResourceLocation(modid, animNameIn);
/*  46 */     this.animChannels.put(anim.toString(), new Channel(anim.toString(), 60.0F, looped));
/*     */   }
/*     */ 
/*     */   
/*     */   public void addAnim(String modid, String animNameIn, CustomChannel customChannelIn) {
/*  51 */     super.addAnim(modid, animNameIn, customChannelIn);
/*  52 */     ResourceLocation anim = new ResourceLocation(modid, animNameIn);
/*  53 */     this.animChannels.put(anim.toString(), new Channel(anim.toString(), 60.0F, false));
/*     */   }
/*     */ 
/*     */   
/*     */   public void addAnim(String modid, String invertedAnimationName, String animationToInvert) {
/*  58 */     super.addAnim(modid, invertedAnimationName, animationToInvert);
/*  59 */     ResourceLocation anim = new ResourceLocation(modid, invertedAnimationName);
/*  60 */     ResourceLocation inverted = new ResourceLocation(modid, animationToInvert);
/*  61 */     boolean looped = ((Channel)this.animChannels.get(inverted.toString())).looped;
/*  62 */     this.animChannels.put(anim.toString(), new Channel(anim.toString(), 60.0F, looped));
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean clientStartAnimation(String res, float startingFrame, T animatedElement) {
/*  67 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean serverInitAnimation(String res, float startingFrame, T animatedElement) {
/*  72 */     if (!this.animChannels.containsKey(res))
/*  73 */       return false; 
/*  74 */     Map<String, Float> startingAnimMap = this.startingAnimations.get(animatedElement);
/*  75 */     if (startingAnimMap == null)
/*  76 */       this.startingAnimations.put(animatedElement, startingAnimMap = new HashMap<>()); 
/*  77 */     startingAnimMap.put(res, Float.valueOf(startingFrame));
/*  78 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean serverStartAnimation(String res, float endingFrame, T animatedElement) {
/*  83 */     if (!this.animChannels.containsKey(res))
/*  84 */       return false; 
/*  85 */     Map<String, Float> startingAnimMap = this.startingAnimations.get(animatedElement);
/*  86 */     if (startingAnimMap == null)
/*  87 */       return false; 
/*  88 */     if (!startingAnimMap.containsKey(res)) {
/*  89 */       return false;
/*     */     }
/*  91 */     Map<String, AnimationHandler.AnimInfo> animInfoMap = this.currentAnimInfo.get(animatedElement);
/*  92 */     if (animInfoMap == null) {
/*  93 */       this.currentAnimInfo.put(animatedElement, animInfoMap = new HashMap<>());
/*     */     }
/*  95 */     Channel anim = this.animChannels.get(res);
/*  96 */     anim.totalFrames = (int)endingFrame;
/*  97 */     animInfoMap.remove(res);
/*     */     
/*  99 */     animInfoMap.put(res, new AnimationHandler.AnimInfo(System.nanoTime(), ((Float)startingAnimMap.get(res)).floatValue()));
/* 100 */     startingAnimMap.remove(res);
/* 101 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean clientStopAnimation(String res, T animatedElement) {
/* 106 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean serverStopAnimation(String res, T animatedElement) {
/* 111 */     Map<String, AnimationHandler.AnimInfo> animInfoMap = this.currentAnimInfo.get(animatedElement);
/* 112 */     if (animInfoMap == null)
/* 113 */       return false; 
/* 114 */     animInfoMap.remove(res);
/* 115 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public void animationsUpdate(T animatedElement) {
/* 120 */     Map<String, AnimationHandler.AnimInfo> animInfoMap = this.currentAnimInfo.get(animatedElement);
/* 121 */     if (animInfoMap == null) {
/*     */       return;
/*     */     }
/* 124 */     for (Iterator<Map.Entry<String, AnimationHandler.AnimInfo>> it = animInfoMap.entrySet().iterator(); it.hasNext(); ) {
/* 125 */       Map.Entry<String, AnimationHandler.AnimInfo> animInfo = it.next();
/* 126 */       boolean animStatus = canUpdateAnimation(this.animChannels.get(animInfo.getKey()), animatedElement);
/* 127 */       if (!animStatus) {
/* 128 */         it.remove();
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   public boolean isAnimationActive(String name, T animatedElement) {
/* 134 */     Map<String, AnimationHandler.AnimInfo> animInfoMap = this.currentAnimInfo.get(animatedElement);
/* 135 */     if (animInfoMap == null) {
/* 136 */       return false;
/*     */     }
/* 138 */     for (Map.Entry<String, AnimationHandler.AnimInfo> animInfo : animInfoMap.entrySet()) {
/* 139 */       if (((String)animInfo.getKey()).equals(name))
/* 140 */         return true; 
/* 141 */     }  return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isHoldAnimationActive(String name, T animatedElement) {
/* 146 */     return isAnimationActive(name, animatedElement);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean canUpdateAnimation(Channel channel, T animatedElement) {
/* 151 */     Map<String, AnimationHandler.AnimInfo> animInfoMap = this.currentAnimInfo.get(animatedElement);
/* 152 */     if (animInfoMap == null) {
/* 153 */       return false;
/*     */     }
/* 155 */     AnimationHandler.AnimInfo animInfo = animInfoMap.get(channel.name);
/* 156 */     if (animInfo == null) {
/* 157 */       return false;
/*     */     }
/* 159 */     long currentTime = System.nanoTime();
/*     */     
/* 161 */     double deltaTime = (currentTime - animInfo.prevTime) / 1.0E9D;
/* 162 */     float numberOfSkippedFrames = (float)(deltaTime * channel.fps);
/*     */     
/* 164 */     float currentFrame = animInfo.currentFrame + numberOfSkippedFrames;
/*     */     
/* 166 */     if (currentFrame < (channel.totalFrames - 1)) {
/* 167 */       animInfo.prevTime = currentTime;
/* 168 */       animInfo.currentFrame = currentFrame;
/* 169 */       return true;
/*     */     } 
/* 171 */     if (channel.looped) {
/* 172 */       animInfo.prevTime = currentTime;
/* 173 */       animInfo.currentFrame = 0.0F;
/* 174 */       return true;
/*     */     } 
/* 176 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\Josep\Downloads\tektopia-1.1.0-deobf.jar!\META-INF\libraries\CraftStudio-1.0.0.93-mc1.12-alpha.jar!\com\leviathanstudio\craftstudio\server\animation\ServerAnimationHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */