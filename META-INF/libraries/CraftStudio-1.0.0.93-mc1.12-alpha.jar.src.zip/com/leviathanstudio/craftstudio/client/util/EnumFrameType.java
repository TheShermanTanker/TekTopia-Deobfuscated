/*    */ package com.leviathanstudio.craftstudio.client.util;
/*    */ 
/*    */ import net.minecraftforge.fml.relauncher.Side;
/*    */ import net.minecraftforge.fml.relauncher.SideOnly;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @SideOnly(Side.CLIENT)
/*    */ public enum EnumFrameType
/*    */ {
/* 16 */   POSITION, ROTATION, OFFSET, SIZE, STRETCH;
/*    */ }


/* Location:              C:\Users\Josep\Downloads\tektopia-1.1.0-deobf.jar!\META-INF\libraries\CraftStudio-1.0.0.93-mc1.12-alpha.jar!\com\leviathanstudio\craftstudio\clien\\util\EnumFrameType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */