/*    */ package com.leviathanstudio.craftstudio.client.util;
/*    */ 
/*    */ import java.nio.ByteBuffer;
/*    */ import java.nio.ByteOrder;
/*    */ import java.nio.FloatBuffer;
/*    */ import javax.vecmath.Matrix4f;
/*    */ import javax.vecmath.Quat4f;
/*    */ import javax.vecmath.Vector3f;
/*    */ import net.minecraftforge.fml.relauncher.Side;
/*    */ import net.minecraftforge.fml.relauncher.SideOnly;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @SideOnly(Side.CLIENT)
/*    */ public class MathHelper
/*    */ {
/*    */   public static FloatBuffer makeFloatBuffer(Matrix4f mat) {
/* 32 */     ByteBuffer bb = ByteBuffer.allocateDirect(64);
/* 33 */     bb.order(ByteOrder.nativeOrder());
/* 34 */     FloatBuffer fb = bb.asFloatBuffer();
/* 35 */     fb.put(mat.m00);
/* 36 */     fb.put(mat.m01);
/* 37 */     fb.put(mat.m02);
/* 38 */     fb.put(mat.m03);
/* 39 */     fb.put(mat.m10);
/* 40 */     fb.put(mat.m11);
/* 41 */     fb.put(mat.m12);
/* 42 */     fb.put(mat.m13);
/* 43 */     fb.put(mat.m20);
/* 44 */     fb.put(mat.m21);
/* 45 */     fb.put(mat.m22);
/* 46 */     fb.put(mat.m23);
/* 47 */     fb.put(mat.m30);
/* 48 */     fb.put(mat.m31);
/* 49 */     fb.put(mat.m32);
/* 50 */     fb.put(mat.m33);
/* 51 */     fb.position(0);
/* 52 */     return fb;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static Quat4f quatFromEuler(Vector3f rot) {
/* 64 */     return quatFromEuler(rot.x, rot.y, rot.z);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static Quat4f quatFromEuler(float pitch, float yaw, float roll) {
/* 80 */     Quat4f quat = new Quat4f();
/* 81 */     pitch = (float)Math.toRadians(pitch);
/* 82 */     yaw = (float)Math.toRadians(yaw);
/* 83 */     roll = (float)Math.toRadians(roll);
/*    */     
/* 85 */     Vector3f coss = new Vector3f();
/* 86 */     coss.x = (float)Math.cos((pitch * 0.5F));
/* 87 */     coss.y = (float)Math.cos((yaw * 0.5F));
/* 88 */     coss.z = (float)Math.cos((roll * 0.5F));
/* 89 */     Vector3f sins = new Vector3f();
/* 90 */     sins.x = (float)Math.sin((pitch * 0.5F));
/* 91 */     sins.y = (float)Math.sin((yaw * 0.5F));
/* 92 */     sins.z = (float)Math.sin((roll * 0.5F));
/*    */     
/* 94 */     quat.w = coss.x * coss.y * coss.z + sins.x * sins.y * sins.z;
/* 95 */     quat.x = sins.x * coss.y * coss.z + coss.x * sins.y * sins.z;
/* 96 */     quat.y = coss.x * sins.y * coss.z - sins.x * coss.y * sins.z;
/* 97 */     quat.z = coss.x * coss.y * sins.z - sins.x * sins.y * coss.z;
/* 98 */     return quat;
/*    */   }
/*    */ }


/* Location:              C:\Users\Josep\Downloads\tektopia-1.1.0-deobf.jar!\META-INF\libraries\CraftStudio-1.0.0.93-mc1.12-alpha.jar!\com\leviathanstudio\craftstudio\clien\\util\MathHelper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */