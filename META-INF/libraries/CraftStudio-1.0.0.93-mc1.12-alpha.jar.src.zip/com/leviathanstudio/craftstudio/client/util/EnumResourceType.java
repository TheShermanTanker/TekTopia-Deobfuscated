/*    */ package com.leviathanstudio.craftstudio.client.util;
/*    */ 
/*    */ import net.minecraftforge.fml.relauncher.Side;
/*    */ import net.minecraftforge.fml.relauncher.SideOnly;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @SideOnly(Side.CLIENT)
/*    */ public enum EnumResourceType
/*    */ {
/* 17 */   MODEL("craftstudio/models/", ".csjsmodel"), ANIM("craftstudio/animations/", ".csjsmodelanim");
/*    */   String extension;
/*    */   String path;
/*    */   
/*    */   EnumResourceType(String pathIn, String extensionIn) {
/* 22 */     this.path = pathIn;
/* 23 */     this.extension = extensionIn;
/*    */   }
/*    */   
/*    */   public String getPath() {
/* 27 */     return this.path;
/*    */   }
/*    */   
/*    */   public String getExtension() {
/* 31 */     return this.extension;
/*    */   }
/*    */ }


/* Location:              C:\Users\Josep\Downloads\tektopia-1.1.0-deobf.jar!\META-INF\libraries\CraftStudio-1.0.0.93-mc1.12-alpha.jar!\com\leviathanstudio\craftstudio\clien\\util\EnumResourceType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */