/*     */ package com.leviathanstudio.craftstudio.client.registry;
/*     */ 
/*     */ import com.leviathanstudio.craftstudio.CraftStudioApi;
/*     */ import com.leviathanstudio.craftstudio.client.exception.CSResourceNotFoundException;
/*     */ import com.leviathanstudio.craftstudio.client.json.CSJsonReader;
/*     */ import com.leviathanstudio.craftstudio.client.util.EnumRenderType;
/*     */ import com.leviathanstudio.craftstudio.client.util.EnumResourceType;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import net.minecraft.util.ResourceLocation;
/*     */ import net.minecraftforge.fml.common.ProgressManager;
/*     */ import net.minecraftforge.fml.relauncher.Side;
/*     */ import net.minecraftforge.fml.relauncher.SideOnly;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @SideOnly(Side.CLIENT)
/*     */ public class CSRegistryHelper
/*     */ {
/*     */   private String modid;
/*  31 */   private static List<LoadElement> loadModelList = new ArrayList<>();
/*  32 */   private static List<LoadElement> loadAnimList = new ArrayList<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CSRegistryHelper(String modid) {
/*  41 */     this.modid = modid;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void register(EnumResourceType resourceTypeIn, EnumRenderType renderTypeIn, String resourceNameIn) {
/*  62 */     capitalCheck(resourceNameIn);
/*  63 */     register(resourceTypeIn, new ResourceLocation(this.modid, resourceTypeIn
/*  64 */           .getPath() + renderTypeIn.getFolderName() + resourceNameIn + resourceTypeIn.getExtension()), resourceNameIn);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void register(EnumResourceType resourceTypeIn, ResourceLocation resourceLocationIn, String resourceNameIn) {
/*  83 */     switch (resourceTypeIn) {
/*     */       case MODEL:
/*  85 */         if (loadModelList != null) {
/*  86 */           loadModelList.add(new LoadElement(resourceLocationIn, resourceNameIn)); break;
/*     */         } 
/*  88 */         CraftStudioApi.getLogger()
/*  89 */           .error("Unable to load model outside of the RegistryEvent.Register<CSReadedModel> event, use forceRegister instead");
/*     */         break;
/*     */       case ANIM:
/*  92 */         if (loadAnimList != null) {
/*  93 */           loadAnimList.add(new LoadElement(resourceLocationIn, resourceNameIn)); break;
/*     */         } 
/*  95 */         CraftStudioApi.getLogger()
/*  96 */           .error("Unable to load animations outside of the RegistryEvent.Register<CSReadedAnim> event, use forceRegister instead");
/*     */         break;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void loadModels() {
/* 105 */     if (loadModelList == null) {
/*     */       return;
/*     */     }
/* 108 */     ProgressManager.ProgressBar progressBarModels = ProgressManager.push("Registry Models", loadModelList.size());
/*     */     
/* 110 */     for (LoadElement el : loadModelList) {
/* 111 */       progressBarModels.step("[" + el.resourceLoc.func_110624_b() + ":" + el.ressourceName + "]");
/* 112 */       registry(EnumResourceType.MODEL, el.resourceLoc, el.ressourceName);
/*     */     } 
/* 114 */     ProgressManager.pop(progressBarModels);
/*     */     
/* 116 */     CraftStudioApi.getLogger().info(String.format("CraftStudioAPI loaded %s models", new Object[] { Integer.valueOf(loadModelList.size()) }));
/* 117 */     loadModelList = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void loadAnims() {
/* 124 */     if (loadAnimList == null) {
/*     */       return;
/*     */     }
/* 127 */     ProgressManager.ProgressBar progressBarAnim = ProgressManager.push("Registry Animations", loadAnimList.size());
/* 128 */     for (LoadElement el : loadAnimList) {
/* 129 */       progressBarAnim.step("[" + el.resourceLoc.func_110624_b() + ":" + el.ressourceName + "]");
/* 130 */       registry(EnumResourceType.ANIM, el.resourceLoc, el.ressourceName);
/*     */     } 
/* 132 */     ProgressManager.pop(progressBarAnim);
/*     */     
/* 134 */     CraftStudioApi.getLogger().info(String.format("CraftStudioAPI loaded %s animations", new Object[] { Integer.valueOf(loadAnimList.size()) }));
/* 135 */     loadAnimList = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void registry(EnumResourceType resourceTypeIn, ResourceLocation resourceLocationIn, String resourceNameIn) {
/*     */     try {
/* 151 */       CSJsonReader jsonReader = new CSJsonReader(resourceLocationIn);
/* 152 */       if (resourceLocationIn.func_110624_b() != "craftstudioapi")
/* 153 */       { switch (resourceTypeIn) {
/*     */           case MODEL:
/* 155 */             RegistryHandler.register(new ResourceLocation(resourceLocationIn.func_110624_b(), resourceNameIn), jsonReader
/* 156 */                 .readModel());
/*     */             break;
/*     */           case ANIM:
/* 159 */             RegistryHandler.register(new ResourceLocation(resourceLocationIn.func_110624_b(), resourceNameIn), jsonReader.readAnim());
/*     */             break;
/*     */         }  }
/*     */       else
/* 163 */       { CraftStudioApi.getLogger().fatal("You're not allowed to use the \"craftstudioapi\" to register CraftStudio resources."); } 
/* 164 */     } catch (CSResourceNotFoundException|com.leviathanstudio.craftstudio.client.exception.CSMalformedJsonException e) {
/* 165 */       e.printStackTrace();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void capitalCheck(String str) {
/* 176 */     if (!str.toLowerCase().equals(str)) {
/* 177 */       CraftStudioApi.getLogger().warn("The resource name \"" + str + "\" contains capitals letters, which is not supported.");
/* 178 */       CraftStudioApi.getLogger().warn("A CSResourceNotFoundException could be raised !");
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static class LoadElement
/*     */   {
/*     */     ResourceLocation resourceLoc;
/*     */ 
/*     */     
/*     */     String ressourceName;
/*     */ 
/*     */ 
/*     */     
/*     */     LoadElement(ResourceLocation resourceLoc, String ressourceName) {
/* 194 */       this.resourceLoc = resourceLoc;
/* 195 */       this.ressourceName = ressourceName;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Josep\Downloads\tektopia-1.1.0-deobf.jar!\META-INF\libraries\CraftStudio-1.0.0.93-mc1.12-alpha.jar!\com\leviathanstudio\craftstudio\client\registry\CSRegistryHelper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */