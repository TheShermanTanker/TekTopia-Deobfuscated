package com.leviathanstudio.craftstudio.client.registry;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

@SideOnly(Side.CLIENT)
@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.METHOD})
public @interface CraftStudioLoader {}


/* Location:              C:\Users\Josep\Downloads\tektopia-1.1.0-deobf.jar!\META-INF\libraries\CraftStudio-1.0.0.93-mc1.12-alpha.jar!\com\leviathanstudio\craftstudio\client\registry\CraftStudioLoader.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */