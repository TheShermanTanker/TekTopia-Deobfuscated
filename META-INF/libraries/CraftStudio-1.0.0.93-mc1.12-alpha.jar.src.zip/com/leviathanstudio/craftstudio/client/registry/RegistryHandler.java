/*    */ package com.leviathanstudio.craftstudio.client.registry;
/*    */ 
/*    */ import com.leviathanstudio.craftstudio.client.json.CSReadedAnim;
/*    */ import com.leviathanstudio.craftstudio.client.json.CSReadedModel;
/*    */ import net.minecraft.util.ResourceLocation;
/*    */ import net.minecraft.util.registry.RegistrySimple;
/*    */ import net.minecraftforge.fml.relauncher.Side;
/*    */ import net.minecraftforge.fml.relauncher.SideOnly;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @SideOnly(Side.CLIENT)
/*    */ public class RegistryHandler
/*    */ {
/*    */   public static RegistrySimple<ResourceLocation, CSReadedModel> modelRegistry;
/*    */   public static RegistrySimple<ResourceLocation, CSReadedAnim> animationRegistry;
/*    */   
/*    */   public static void init() {
/* 28 */     modelRegistry = new RegistrySimple();
/* 29 */     animationRegistry = new RegistrySimple();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static void register(ResourceLocation res, CSReadedModel model) {
/* 41 */     modelRegistry.func_82595_a(res, model);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static void register(ResourceLocation res, CSReadedAnim anim) {
/* 53 */     animationRegistry.func_82595_a(res, anim);
/*    */   }
/*    */ }


/* Location:              C:\Users\Josep\Downloads\tektopia-1.1.0-deobf.jar!\META-INF\libraries\CraftStudio-1.0.0.93-mc1.12-alpha.jar!\com\leviathanstudio\craftstudio\client\registry\RegistryHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */