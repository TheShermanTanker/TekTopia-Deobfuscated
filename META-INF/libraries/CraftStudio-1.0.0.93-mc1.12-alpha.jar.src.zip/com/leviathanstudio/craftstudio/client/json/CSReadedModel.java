/*    */ package com.leviathanstudio.craftstudio.client.json;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import net.minecraftforge.fml.relauncher.Side;
/*    */ import net.minecraftforge.fml.relauncher.SideOnly;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @SideOnly(Side.CLIENT)
/*    */ public class CSReadedModel
/*    */ {
/*    */   private String name;
/*    */   private int textureWidth;
/*    */   private int textureHeight;
/* 21 */   private List<CSReadedModelBlock> parents = new ArrayList<>();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public CSReadedModelBlock getBlockFromName(String name) {
/* 34 */     for (CSReadedModelBlock block : this.parents) {
/* 35 */       CSReadedModelBlock b = block.getBlockFromName(name);
/* 36 */       if (b != null)
/* 37 */         return b; 
/*    */     } 
/* 39 */     return null;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean isAnimable() {
/* 49 */     if (whyUnAnimable() == null)
/* 50 */       return true; 
/* 51 */     return false;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String whyUnAnimable() {
/* 61 */     List<String> names = new ArrayList<>();
/* 62 */     for (CSReadedModelBlock block : this.parents) {
/* 63 */       String str = block.whyUnAnimable(names);
/* 64 */       if (str != null)
/* 65 */         return str; 
/*    */     } 
/* 67 */     return null;
/*    */   }
/*    */   
/*    */   public String getName() {
/* 71 */     return this.name;
/*    */   }
/*    */   
/*    */   public void setName(String name) {
/* 75 */     this.name = name;
/*    */   }
/*    */   
/*    */   public int getTextureWidth() {
/* 79 */     return this.textureWidth;
/*    */   }
/*    */   
/*    */   public void setTextureWidth(int textureWidth) {
/* 83 */     this.textureWidth = textureWidth;
/*    */   }
/*    */   
/*    */   public int getTextureHeight() {
/* 87 */     return this.textureHeight;
/*    */   }
/*    */   
/*    */   public void setTextureHeight(int textureHeight) {
/* 91 */     this.textureHeight = textureHeight;
/*    */   }
/*    */   
/*    */   public List<CSReadedModelBlock> getParents() {
/* 95 */     return this.parents;
/*    */   }
/*    */   
/*    */   public void setParents(List<CSReadedModelBlock> parents) {
/* 99 */     this.parents = parents;
/*    */   }
/*    */ }


/* Location:              C:\Users\Josep\Downloads\tektopia-1.1.0-deobf.jar!\META-INF\libraries\CraftStudio-1.0.0.93-mc1.12-alpha.jar!\com\leviathanstudio\craftstudio\client\json\CSReadedModel.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */