/*     */ package com.leviathanstudio.craftstudio.client.json;
/*     */ 
/*     */ import com.google.gson.JsonArray;
/*     */ import com.google.gson.JsonElement;
/*     */ import com.google.gson.JsonObject;
/*     */ import com.google.gson.JsonParser;
/*     */ import com.leviathanstudio.craftstudio.CraftStudioApi;
/*     */ import com.leviathanstudio.craftstudio.client.exception.CSMalformedJsonException;
/*     */ import com.leviathanstudio.craftstudio.client.exception.CSResourceNotFoundException;
/*     */ import com.leviathanstudio.craftstudio.client.util.EnumFrameType;
/*     */ import java.io.BufferedReader;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.InputStreamReader;
/*     */ import java.util.Map;
/*     */ import javax.vecmath.Vector3f;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.resources.IResource;
/*     */ import net.minecraft.util.ResourceLocation;
/*     */ import net.minecraftforge.fml.relauncher.Side;
/*     */ import net.minecraftforge.fml.relauncher.SideOnly;
/*     */ import org.apache.commons.io.Charsets;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @SideOnly(Side.CLIENT)
/*     */ public class CSJsonReader
/*     */ {
/*     */   private JsonObject root;
/*     */   private String ress;
/*     */   
/*     */   public CSJsonReader(ResourceLocation resourceIn) throws CSResourceNotFoundException {
/*  58 */     JsonParser jsonParser = new JsonParser();
/*  59 */     BufferedReader reader = null;
/*  60 */     IResource iResource = null;
/*  61 */     StringBuilder strBuilder = new StringBuilder();
/*  62 */     this.ress = resourceIn.toString();
/*     */     
/*     */     try {
/*  65 */       iResource = Minecraft.func_71410_x().func_110442_L().func_110536_a(resourceIn);
/*  66 */       reader = new BufferedReader(new InputStreamReader(iResource.func_110527_b(), Charsets.UTF_8));
/*     */       String s;
/*  68 */       while ((s = reader.readLine()) != null)
/*  69 */         strBuilder.append(s); 
/*  70 */       Object object = jsonParser.parse(strBuilder.toString());
/*  71 */       this.root = (JsonObject)object;
/*  72 */     } catch (FileNotFoundException fnfe) {
/*  73 */       throw new CSResourceNotFoundException(this.ress);
/*  74 */     } catch (Exception e) {
/*  75 */       e.printStackTrace();
/*     */     } finally {
/*     */       try {
/*  78 */         if (reader != null)
/*  79 */           reader.close(); 
/*  80 */         if (iResource != null)
/*  81 */           iResource.close(); 
/*  82 */       } catch (Exception e) {
/*  83 */         e.printStackTrace();
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CSReadedModel readModel() throws CSMalformedJsonException {
/*  98 */     CSReadedModel model = new CSReadedModel();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 103 */     JsonElement jsEl = this.root.get("title");
/* 104 */     if (jsEl == null)
/* 105 */       throw new CSMalformedJsonException("title", "String", this.ress); 
/* 106 */     model.setName(strNormalize(jsEl.getAsString()));
/*     */     
/* 108 */     JsonArray tree = this.root.getAsJsonArray("tree");
/* 109 */     if (tree == null)
/* 110 */       throw new CSMalformedJsonException("tree", "Array", this.ress); 
/* 111 */     for (JsonElement element : tree) {
/* 112 */       if (element.isJsonObject()) {
/* 113 */         JsonObject jsonBlock = element.getAsJsonObject();
/*     */         
/* 115 */         CSReadedModelBlock parent = new CSReadedModelBlock();
/* 116 */         model.getParents().add(parent);
/*     */         
/*     */         try {
/* 119 */           readModelBlock(jsonBlock, parent);
/* 120 */         } catch (NullPointerException|ClassCastException|IllegalStateException e) {
/*     */           
/* 122 */           throw new CSMalformedJsonException((parent.getName() != null) ? parent.getName() : "a parent block without name", this.ress);
/*     */         } 
/*     */       } 
/* 125 */     }  return model;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void readModelBlock(JsonObject jsonBlock, CSReadedModelBlock block) {
/* 138 */     readModelBlock(jsonBlock, block, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void readModelBlock(JsonObject jsonBlock, CSReadedModelBlock block, Vector3f parentOffset) {
/* 153 */     int[] vertexOrderConvert = { 3, 2, 1, 0, 6, 7, 4, 5 };
/*     */ 
/*     */ 
/*     */     
/* 157 */     block.setName(strNormalize(jsonBlock.get("name").getAsString()));
/*     */     
/* 159 */     JsonArray array = jsonBlock.getAsJsonArray("size");
/* 160 */     float sizeX = array.get(0).getAsFloat();
/* 161 */     float sizeY = array.get(1).getAsFloat();
/* 162 */     float sizeZ = array.get(2).getAsFloat();
/*     */     
/* 164 */     array = jsonBlock.getAsJsonArray("position");
/* 165 */     float posX = array.get(0).getAsFloat();
/* 166 */     float posY = array.get(1).getAsFloat();
/* 167 */     float posZ = array.get(2).getAsFloat();
/*     */     
/* 169 */     array = jsonBlock.getAsJsonArray("rotation");
/* 170 */     float rotationX = array.get(0).getAsFloat();
/* 171 */     float rotationY = array.get(1).getAsFloat();
/* 172 */     float rotationZ = array.get(2).getAsFloat();
/*     */     
/* 174 */     array = jsonBlock.getAsJsonArray("offsetFromPivot");
/* 175 */     float pivotOffsetX = array.get(0).getAsFloat();
/* 176 */     float pivotOffsetY = array.get(1).getAsFloat();
/* 177 */     float pivotOffsetZ = array.get(2).getAsFloat();
/*     */ 
/*     */ 
/*     */     
/* 181 */     array = jsonBlock.getAsJsonArray("vertexCoords");
/* 182 */     if (array != null) {
/* 183 */       block.setVertex(new float[8][3]);
/* 184 */       for (int i = 0; i < 8; i++) {
/* 185 */         JsonArray vertexArray = array.get(vertexOrderConvert[i]).getAsJsonArray();
/* 186 */         block.getVertex()[i][0] = vertexArray.get(0).getAsFloat();
/* 187 */         block.getVertex()[i][1] = -vertexArray.get(1).getAsFloat();
/* 188 */         block.getVertex()[i][2] = -vertexArray.get(2).getAsFloat();
/*     */       } 
/* 190 */       float stretchx = (sizeX != 0.0F) ? (Math.abs(block.getVertex()[1][0] - block.getVertex()[0][0]) / sizeX) : 1.0F;
/* 191 */       float stretchy = (sizeY != 0.0F) ? (Math.abs(block.getVertex()[3][1] - block.getVertex()[0][1]) / sizeY) : 1.0F;
/* 192 */       float stretchz = (sizeZ != 0.0F) ? (Math.abs(block.getVertex()[4][2] - block.getVertex()[0][2]) / sizeZ) : 1.0F;
/*     */       
/* 194 */       for (int j = 0; j < 8; j++) {
/* 195 */         float[] vertex = block.getVertex()[j];
/* 196 */         vertex[0] = vertex[0] / stretchx;
/* 197 */         vertex[1] = vertex[1] / stretchy;
/* 198 */         vertex[2] = vertex[2] / stretchz;
/*     */       } 
/*     */       
/* 201 */       block.setStretch(new Vector3f(stretchx, stretchy, stretchz));
/*     */     } else {
/*     */       
/* 204 */       block.setStretch(new Vector3f(1.0F, 1.0F, 1.0F));
/*     */     } 
/* 206 */     if (parentOffset == null) {
/* 207 */       block.setRotationPoint(new Vector3f(posX, -posY + 24.0F, -posZ));
/*     */     } else {
/* 209 */       block.setRotationPoint(new Vector3f(posX, -posY, -posZ));
/* 210 */     }  block.setRotation(new Vector3f(rotationX, -rotationY, -rotationZ));
/* 211 */     block.setOffset(new Vector3f(pivotOffsetX, -pivotOffsetY, -pivotOffsetZ));
/* 212 */     block.setSize(new Vector3f(sizeX, -sizeY, -sizeZ));
/*     */     
/* 214 */     array = jsonBlock.getAsJsonArray("texOffset");
/* 215 */     block.getTexOffset()[0] = array.get(0).getAsInt();
/* 216 */     block.getTexOffset()[1] = array.get(1).getAsInt();
/*     */     
/* 218 */     array = jsonBlock.getAsJsonArray("children");
/* 219 */     for (JsonElement element : array) {
/* 220 */       JsonObject jsonChild = element.getAsJsonObject();
/* 221 */       CSReadedModelBlock child = new CSReadedModelBlock();
/* 222 */       block.getChilds().add(child);
/* 223 */       readModelBlock(jsonChild, child, new Vector3f(pivotOffsetX, -pivotOffsetY, -pivotOffsetZ));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CSReadedAnim readAnim() throws CSMalformedJsonException {
/* 238 */     CSReadedAnim anim = new CSReadedAnim();
/*     */ 
/*     */ 
/*     */     
/* 242 */     JsonElement jsEl = this.root.get("title");
/* 243 */     if (jsEl == null)
/* 244 */       throw new CSMalformedJsonException("title", "String", this.ress); 
/* 245 */     anim.setName(strNormalize(jsEl.getAsString()));
/* 246 */     jsEl = this.root.get("duration");
/* 247 */     if (jsEl == null)
/* 248 */       throw new CSMalformedJsonException("duration", "Integer", this.ress); 
/* 249 */     anim.setDuration(jsEl.getAsInt());
/* 250 */     jsEl = this.root.get("holdLastKeyframe");
/* 251 */     if (jsEl == null)
/* 252 */       throw new CSMalformedJsonException("holdLastKeyframe", "Boolean", this.ress); 
/* 253 */     anim.setHoldLastK(jsEl.getAsBoolean());
/*     */     
/* 255 */     jsEl = this.root.get("nodeAnimations");
/* 256 */     if (jsEl == null)
/* 257 */       throw new CSMalformedJsonException("nodeAnimations", "Object", this.ress); 
/* 258 */     JsonObject nodeAnims = jsEl.getAsJsonObject();
/* 259 */     for (Map.Entry<String, JsonElement> entry : (Iterable<Map.Entry<String, JsonElement>>)nodeAnims.entrySet()) {
/* 260 */       CSReadedAnimBlock block = new CSReadedAnimBlock();
/* 261 */       anim.getBlocks().add(block);
/*     */       try {
/* 263 */         readAnimBlock(entry, block);
/* 264 */       } catch (Exception e) {
/* 265 */         CraftStudioApi.getLogger().error(e.getMessage());
/* 266 */         throw new CSMalformedJsonException((block.getName() != null) ? block.getName() : "a block without name", this.ress);
/*     */       } 
/*     */     } 
/* 269 */     return anim;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void readAnimBlock(Map.Entry<String, JsonElement> entry, CSReadedAnimBlock block) {
/* 282 */     block.setName(strNormalize(entry.getKey()));
/* 283 */     JsonObject objBlock = ((JsonElement)entry.getValue()).getAsJsonObject();
/*     */     
/* 285 */     JsonObject objField = objBlock.get("position").getAsJsonObject();
/* 286 */     addKFElement(objField, block, EnumFrameType.POSITION);
/* 287 */     objField = objBlock.get("offsetFromPivot").getAsJsonObject();
/* 288 */     addKFElement(objField, block, EnumFrameType.OFFSET);
/* 289 */     objField = objBlock.get("size").getAsJsonObject();
/* 290 */     addKFElement(objField, block, EnumFrameType.SIZE);
/* 291 */     objField = objBlock.get("rotation").getAsJsonObject();
/* 292 */     addKFElement(objField, block, EnumFrameType.ROTATION);
/* 293 */     objField = objBlock.get("stretch").getAsJsonObject();
/* 294 */     addKFElement(objField, block, EnumFrameType.STRETCH);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void addKFElement(JsonObject obj, CSReadedAnimBlock block, EnumFrameType type) {
/* 312 */     for (Map.Entry<String, JsonElement> entry : (Iterable<Map.Entry<String, JsonElement>>)obj.entrySet()) {
/* 313 */       Vector3f value; int keyFrame = Integer.parseInt(entry.getKey());
/* 314 */       JsonArray array = ((JsonElement)entry.getValue()).getAsJsonArray();
/* 315 */       switch (type) {
/*     */         case STRETCH:
/*     */         case SIZE:
/* 318 */           value = new Vector3f(array.get(0).getAsFloat(), array.get(1).getAsFloat(), array.get(2).getAsFloat());
/*     */           break;
/*     */         default:
/* 321 */           value = new Vector3f(array.get(0).getAsFloat(), -array.get(1).getAsFloat(), -array.get(2).getAsFloat()); break;
/*     */       } 
/* 323 */       block.addKFElement(keyFrame, type, value);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static String strNormalize(String str) {
/* 335 */     return str.replaceAll("[^\\dA-Za-z ]", "_").replaceAll("\\s+", "_").replaceAll("[^\\p{ASCII}]", "_");
/*     */   }
/*     */ }


/* Location:              C:\Users\Josep\Downloads\tektopia-1.1.0-deobf.jar!\META-INF\libraries\CraftStudio-1.0.0.93-mc1.12-alpha.jar!\com\leviathanstudio\craftstudio\client\json\CSJsonReader.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */