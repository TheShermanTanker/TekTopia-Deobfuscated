/*    */ package com.leviathanstudio.craftstudio.client.json;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.HashSet;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ import java.util.Set;
/*    */ import net.minecraftforge.fml.relauncher.Side;
/*    */ import net.minecraftforge.fml.relauncher.SideOnly;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @SideOnly(Side.CLIENT)
/*    */ public class CSReadedAnim
/*    */ {
/*    */   private String name;
/*    */   private int duration;
/*    */   private boolean holdLastK;
/* 27 */   private List<CSReadedAnimBlock> blocks = new ArrayList<>();
/*    */ 
/*    */ 
/*    */   
/*    */   private Integer[] keyFrames;
/*    */ 
/*    */ 
/*    */   
/*    */   public Integer[] getKeyFrames() {
/* 36 */     if (this.keyFrames != null) {
/* 37 */       return this.keyFrames;
/*    */     }
/* 39 */     Set set = new HashSet();
/* 40 */     for (CSReadedAnimBlock block : this.blocks) {
/* 41 */       for (Map.Entry<Integer, CSReadedAnimBlock.ReadedKeyFrame> entry : block.getKeyFrames().entrySet())
/* 42 */         set.add(entry.getKey()); 
/*    */     } 
/* 44 */     Integer[] tab = new Integer[1];
/* 45 */     tab = (Integer[])set.toArray((Object[])tab);
/* 46 */     return tab;
/*    */   }
/*    */   
/*    */   public String getName() {
/* 50 */     return this.name;
/*    */   }
/*    */   
/*    */   public void setName(String name) {
/* 54 */     this.name = name;
/*    */   }
/*    */   
/*    */   public int getDuration() {
/* 58 */     return this.duration;
/*    */   }
/*    */   
/*    */   public void setDuration(int duration) {
/* 62 */     this.duration = duration;
/*    */   }
/*    */   
/*    */   public boolean isHoldLastK() {
/* 66 */     return this.holdLastK;
/*    */   }
/*    */   
/*    */   public void setHoldLastK(boolean holdLastK) {
/* 70 */     this.holdLastK = holdLastK;
/*    */   }
/*    */   
/*    */   public List<CSReadedAnimBlock> getBlocks() {
/* 74 */     return this.blocks;
/*    */   }
/*    */   
/*    */   public void setBlocks(List<CSReadedAnimBlock> blocks) {
/* 78 */     this.blocks = blocks;
/*    */   }
/*    */ }


/* Location:              C:\Users\Josep\Downloads\tektopia-1.1.0-deobf.jar!\META-INF\libraries\CraftStudio-1.0.0.93-mc1.12-alpha.jar!\com\leviathanstudio\craftstudio\client\json\CSReadedAnim.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */