/*     */ package com.leviathanstudio.craftstudio.client.json;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import javax.vecmath.Vector3f;
/*     */ import net.minecraftforge.fml.relauncher.Side;
/*     */ import net.minecraftforge.fml.relauncher.SideOnly;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @SideOnly(Side.CLIENT)
/*     */ public class CSReadedModelBlock
/*     */ {
/*     */   private String name;
/*     */   private Vector3f rotationPoint;
/*     */   private Vector3f rotation;
/*     */   private Vector3f size;
/*     */   private Vector3f stretch;
/*     */   private Vector3f offset;
/*     */   private float[][] vertex;
/*  24 */   private int[] texOffset = new int[2];
/*  25 */   private List<CSReadedModelBlock> childs = new ArrayList<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   CSReadedModelBlock getBlockFromName(String name) {
/*  36 */     if (this.name.equals(name))
/*  37 */       return this; 
/*  38 */     for (CSReadedModelBlock block : this.childs) {
/*  39 */       CSReadedModelBlock b = block.getBlockFromName(name);
/*  40 */       if (b != null)
/*  41 */         return b; 
/*     */     } 
/*  43 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   String whyUnAnimable(List<String> names) {
/*  57 */     if (names.contains(this.name))
/*  58 */       return this.name; 
/*  59 */     names.add(this.name);
/*  60 */     for (CSReadedModelBlock block : this.childs) {
/*  61 */       String str = block.whyUnAnimable(names);
/*  62 */       if (str != null)
/*  63 */         return str; 
/*     */     } 
/*  65 */     return null;
/*     */   }
/*     */   
/*     */   public String getName() {
/*  69 */     return this.name;
/*     */   }
/*     */   
/*     */   public void setName(String name) {
/*  73 */     this.name = name;
/*     */   }
/*     */   
/*     */   public Vector3f getRotationPoint() {
/*  77 */     return this.rotationPoint;
/*     */   }
/*     */   
/*     */   public void setRotationPoint(Vector3f rotationPoint) {
/*  81 */     this.rotationPoint = rotationPoint;
/*     */   }
/*     */   
/*     */   public Vector3f getRotation() {
/*  85 */     return this.rotation;
/*     */   }
/*     */   
/*     */   public void setRotation(Vector3f rotation) {
/*  89 */     this.rotation = rotation;
/*     */   }
/*     */   
/*     */   public Vector3f getSize() {
/*  93 */     return this.size;
/*     */   }
/*     */   
/*     */   public void setSize(Vector3f size) {
/*  97 */     this.size = size;
/*     */   }
/*     */   
/*     */   public Vector3f getStretch() {
/* 101 */     return this.stretch;
/*     */   }
/*     */   
/*     */   public void setStretch(Vector3f stretch) {
/* 105 */     this.stretch = stretch;
/*     */   }
/*     */   
/*     */   public Vector3f getOffset() {
/* 109 */     return this.offset;
/*     */   }
/*     */   
/*     */   public void setOffset(Vector3f offset) {
/* 113 */     this.offset = offset;
/*     */   }
/*     */   
/*     */   public float[][] getVertex() {
/* 117 */     return this.vertex;
/*     */   }
/*     */   
/*     */   public void setVertex(float[][] vertex) {
/* 121 */     this.vertex = vertex;
/*     */   }
/*     */   
/*     */   public int[] getTexOffset() {
/* 125 */     return this.texOffset;
/*     */   }
/*     */   
/*     */   public void setTexOffset(int[] texOffset) {
/* 129 */     this.texOffset = texOffset;
/*     */   }
/*     */   
/*     */   public List<CSReadedModelBlock> getChilds() {
/* 133 */     return this.childs;
/*     */   }
/*     */   
/*     */   public void setChilds(List<CSReadedModelBlock> childs) {
/* 137 */     this.childs = childs;
/*     */   }
/*     */ }


/* Location:              C:\Users\Josep\Downloads\tektopia-1.1.0-deobf.jar!\META-INF\libraries\CraftStudio-1.0.0.93-mc1.12-alpha.jar!\com\leviathanstudio\craftstudio\client\json\CSReadedModelBlock.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */