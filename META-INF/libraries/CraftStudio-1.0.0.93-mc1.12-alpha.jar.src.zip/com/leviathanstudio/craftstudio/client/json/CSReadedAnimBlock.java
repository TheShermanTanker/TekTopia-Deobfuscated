/*    */ package com.leviathanstudio.craftstudio.client.json;
/*    */ 
/*    */ import com.leviathanstudio.craftstudio.client.util.EnumFrameType;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import javax.vecmath.Vector3f;
/*    */ import net.minecraftforge.fml.relauncher.Side;
/*    */ import net.minecraftforge.fml.relauncher.SideOnly;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @SideOnly(Side.CLIENT)
/*    */ public class CSReadedAnimBlock
/*    */ {
/*    */   private String name;
/* 24 */   private Map<Integer, ReadedKeyFrame> keyFrames = new HashMap<>();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void addKFElement(int keyFrame, EnumFrameType type, Vector3f value) {
/* 37 */     if (!this.keyFrames.containsKey(Integer.valueOf(keyFrame)))
/* 38 */       this.keyFrames.put(Integer.valueOf(keyFrame), new ReadedKeyFrame()); 
/* 39 */     switch (type) {
/*    */       case POSITION:
/* 41 */         ((ReadedKeyFrame)this.keyFrames.get(Integer.valueOf(keyFrame))).position = value;
/*    */         break;
/*    */       case ROTATION:
/* 44 */         ((ReadedKeyFrame)this.keyFrames.get(Integer.valueOf(keyFrame))).rotation = value;
/*    */         break;
/*    */       case OFFSET:
/* 47 */         ((ReadedKeyFrame)this.keyFrames.get(Integer.valueOf(keyFrame))).offset = value;
/*    */         break;
/*    */       case SIZE:
/* 50 */         ((ReadedKeyFrame)this.keyFrames.get(Integer.valueOf(keyFrame))).size = value;
/*    */         break;
/*    */       case STRETCH:
/* 53 */         ((ReadedKeyFrame)this.keyFrames.get(Integer.valueOf(keyFrame))).stretching = value;
/*    */         break;
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public class ReadedKeyFrame
/*    */   {
/*    */     public Vector3f position;
/*    */     
/*    */     public Vector3f rotation;
/*    */     
/*    */     public Vector3f offset;
/*    */     public Vector3f size;
/*    */     public Vector3f stretching;
/*    */   }
/*    */   
/*    */   public String getName() {
/* 71 */     return this.name;
/*    */   }
/*    */   
/*    */   public void setName(String name) {
/* 75 */     this.name = name;
/*    */   }
/*    */   
/*    */   public Map<Integer, ReadedKeyFrame> getKeyFrames() {
/* 79 */     return this.keyFrames;
/*    */   }
/*    */   
/*    */   public void setKeyFrames(Map<Integer, ReadedKeyFrame> keyFrames) {
/* 83 */     this.keyFrames = keyFrames;
/*    */   }
/*    */ }


/* Location:              C:\Users\Josep\Downloads\tektopia-1.1.0-deobf.jar!\META-INF\libraries\CraftStudio-1.0.0.93-mc1.12-alpha.jar!\com\leviathanstudio\craftstudio\client\json\CSReadedAnimBlock.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */