/*    */ package com.leviathanstudio.craftstudio.client.exception;
/*    */ 
/*    */ import net.minecraftforge.fml.relauncher.Side;
/*    */ import net.minecraftforge.fml.relauncher.SideOnly;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @SideOnly(Side.CLIENT)
/*    */ public class CSMalformedJsonException
/*    */   extends Exception
/*    */ {
/*    */   private static final long serialVersionUID = -3495512445212088386L;
/*    */   
/*    */   public CSMalformedJsonException(String field, String type, String ress) {
/* 30 */     super("Missing field " + field + " of type " + type + " in " + ress);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public CSMalformedJsonException(String element, String ress) {
/* 42 */     super("Malformation of " + element + " in " + ress);
/*    */   }
/*    */ }


/* Location:              C:\Users\Josep\Downloads\tektopia-1.1.0-deobf.jar!\META-INF\libraries\CraftStudio-1.0.0.93-mc1.12-alpha.jar!\com\leviathanstudio\craftstudio\client\exception\CSMalformedJsonException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */