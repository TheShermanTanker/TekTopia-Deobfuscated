/*     */ package com.leviathanstudio.craftstudio.client.animation;
/*     */ 
/*     */ import com.leviathanstudio.craftstudio.CraftStudioApi;
/*     */ import com.leviathanstudio.craftstudio.client.model.CSModelRenderer;
/*     */ import com.leviathanstudio.craftstudio.common.animation.AnimationHandler;
/*     */ import com.leviathanstudio.craftstudio.common.animation.Channel;
/*     */ import com.leviathanstudio.craftstudio.common.animation.CustomChannel;
/*     */ import com.leviathanstudio.craftstudio.common.animation.IAnimated;
/*     */ import com.leviathanstudio.craftstudio.common.animation.InfoChannel;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.WeakHashMap;
/*     */ import javax.vecmath.Matrix4f;
/*     */ import javax.vecmath.Quat4f;
/*     */ import javax.vecmath.Tuple3f;
/*     */ import javax.vecmath.Vector3f;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.model.ModelRenderer;
/*     */ import net.minecraft.util.ResourceLocation;
/*     */ import net.minecraftforge.fml.relauncher.Side;
/*     */ import net.minecraftforge.fml.relauncher.SideOnly;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @SideOnly(Side.CLIENT)
/*     */ public class ClientAnimationHandler<T extends IAnimated>
/*     */   extends AnimationHandler<T>
/*     */ {
/*  45 */   private Map<String, InfoChannel> animChannels = new HashMap<>();
/*     */ 
/*     */   
/*  48 */   private Map<T, Map<InfoChannel, AnimationHandler.AnimInfo>> currentAnimInfo = new WeakHashMap<>();
/*     */ 
/*     */   
/*     */   public void addAnim(String modid, String animNameIn, String modelNameIn, boolean looped) {
/*  52 */     super.addAnim(modid, animNameIn, modelNameIn, looped);
/*  53 */     ResourceLocation anim = new ResourceLocation(modid, animNameIn), model = new ResourceLocation(modid, modelNameIn);
/*  54 */     this.animChannels.put(anim.toString(), new CSAnimChannel(anim, model, looped));
/*     */   }
/*     */ 
/*     */   
/*     */   public void addAnim(String modid, String animNameIn, CustomChannel customChannelIn) {
/*  59 */     super.addAnim(modid, animNameIn, customChannelIn);
/*  60 */     ResourceLocation anim = new ResourceLocation(modid, animNameIn);
/*  61 */     this.animChannels.put(anim.toString(), customChannelIn);
/*     */   }
/*     */ 
/*     */   
/*     */   public void addAnim(String modid, String invertedAnimationName, String animationToInvert) {
/*  66 */     super.addAnim(modid, invertedAnimationName, animationToInvert);
/*  67 */     ResourceLocation anim = new ResourceLocation(modid, invertedAnimationName);
/*  68 */     ResourceLocation toInvert = new ResourceLocation(modid, animationToInvert);
/*  69 */     if (this.animChannels.get(toInvert.toString()) instanceof ClientChannel) {
/*  70 */       ClientChannel channel = ((ClientChannel)this.animChannels.get(toInvert.toString())).getInvertedChannel(invertedAnimationName);
/*  71 */       channel.name = anim.toString();
/*  72 */       this.animChannels.put(anim.toString(), channel);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean clientStartAnimation(String res, float startingFrame, T animatedElement) {
/*  78 */     if (this.animChannels.get(res) == null) {
/*  79 */       CraftStudioApi.getLogger().warn("The animation called " + res + " doesn't exist!");
/*  80 */       return false;
/*     */     } 
/*  82 */     Map<InfoChannel, AnimationHandler.AnimInfo> animInfoMap = this.currentAnimInfo.get(animatedElement);
/*  83 */     if (animInfoMap == null) {
/*  84 */       this.currentAnimInfo.put(animatedElement, animInfoMap = new HashMap<>());
/*     */     }
/*  86 */     InfoChannel selectedChannel = this.animChannels.get(res);
/*  87 */     animInfoMap.remove(selectedChannel);
/*     */     
/*  89 */     animInfoMap.put(selectedChannel, new AnimationHandler.AnimInfo(System.nanoTime(), startingFrame));
/*  90 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean serverInitAnimation(String res, float startingFrame, T animatedElement) {
/*  95 */     if (!this.animChannels.containsKey(res))
/*  96 */       return false; 
/*  97 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean serverStartAnimation(String res, float endingFrame, T animatedElement) {
/* 102 */     if (!this.animChannels.containsKey(res))
/* 103 */       return false; 
/* 104 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean clientStopAnimation(String res, T animatedElement) {
/* 109 */     if (!this.animChannels.containsKey(res)) {
/* 110 */       CraftStudioApi.getLogger().warn("The animation stopped " + res + " doesn't exist!");
/* 111 */       return false;
/*     */     } 
/*     */     
/* 114 */     Map<InfoChannel, AnimationHandler.AnimInfo> animInfoMap = this.currentAnimInfo.get(animatedElement);
/* 115 */     if (animInfoMap == null) {
/* 116 */       return false;
/*     */     }
/* 118 */     InfoChannel selectedChannel = this.animChannels.get(res);
/* 119 */     animInfoMap.remove(selectedChannel);
/* 120 */     if (animInfoMap.isEmpty())
/* 121 */       this.currentAnimInfo.remove(animatedElement); 
/* 122 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean serverStopAnimation(String res, T animatedElement) {
/* 127 */     return this.currentAnimInfo.containsKey(animatedElement);
/*     */   }
/*     */ 
/*     */   
/*     */   public void animationsUpdate(T animatedElement) {
/* 132 */     Map<InfoChannel, AnimationHandler.AnimInfo> animInfoMap = this.currentAnimInfo.get(animatedElement);
/* 133 */     if (animInfoMap == null) {
/*     */       return;
/*     */     }
/* 136 */     for (Iterator<Map.Entry<InfoChannel, AnimationHandler.AnimInfo>> it = animInfoMap.entrySet().iterator(); it.hasNext(); ) {
/* 137 */       Map.Entry<InfoChannel, AnimationHandler.AnimInfo> animInfo = it.next();
/* 138 */       animInfo.getValue();
/* 139 */       boolean canUpdate = canUpdateAnimation((Channel)animInfo.getKey(), animatedElement);
/* 140 */       if (!canUpdate) {
/* 141 */         it.remove();
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   public boolean isAnimationActive(String name, T animatedElement) {
/* 147 */     InfoChannel anim = this.animChannels.get(name);
/* 148 */     if (anim == null)
/* 149 */       return false; 
/* 150 */     Map<InfoChannel, AnimationHandler.AnimInfo> animInfoMap = this.currentAnimInfo.get(animatedElement);
/* 151 */     if (animInfoMap == null)
/* 152 */       return false; 
/* 153 */     if (animInfoMap.containsKey(anim)) {
/* 154 */       AnimationHandler.AnimInfo info = animInfoMap.get(anim);
/* 155 */       if (anim instanceof CustomChannel || info.currentFrame < (anim.totalFrames - 1))
/* 156 */         return true; 
/*     */     } 
/* 158 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isHoldAnimationActive(String name, T animatedElement) {
/* 163 */     InfoChannel anim = this.animChannels.get(name);
/* 164 */     if (anim == null)
/* 165 */       return false; 
/* 166 */     Map<InfoChannel, AnimationHandler.AnimInfo> animInfoMap = this.currentAnimInfo.get(animatedElement);
/* 167 */     if (animInfoMap == null)
/* 168 */       return false; 
/* 169 */     if (animInfoMap.containsKey(anim))
/* 170 */       return true; 
/* 171 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean canUpdateAnimation(Channel channel, T animatedElement) {
/* 176 */     Map<InfoChannel, AnimationHandler.AnimInfo> animInfoMap = this.currentAnimInfo.get(animatedElement);
/* 177 */     if (animInfoMap == null) {
/* 178 */       return false;
/*     */     }
/* 180 */     long currentTime = System.nanoTime();
/* 181 */     if (!(channel instanceof InfoChannel))
/* 182 */       return false; 
/* 183 */     InfoChannel infoChannel = (InfoChannel)channel;
/* 184 */     AnimationHandler.AnimInfo animInfo = animInfoMap.get(channel);
/* 185 */     if (!isGamePaused()) {
/* 186 */       if (infoChannel instanceof ClientChannel) {
/* 187 */         ClientChannel clientChannel = (ClientChannel)infoChannel;
/*     */         
/* 189 */         double deltaTime = (currentTime - animInfo.prevTime) / 1.0E9D;
/* 190 */         float numberOfSkippedFrames = (float)(deltaTime * channel.fps);
/*     */         
/* 192 */         float currentFrame = animInfo.currentFrame + numberOfSkippedFrames;
/*     */         
/* 194 */         if (currentFrame < (clientChannel.totalFrames - 1)) {
/* 195 */           animInfo.prevTime = currentTime;
/* 196 */           animInfo.currentFrame = currentFrame;
/* 197 */           return true;
/*     */         } 
/* 199 */         if (clientChannel.getAnimationMode() == EnumAnimationMode.LOOP) {
/* 200 */           animInfo.prevTime = currentTime;
/* 201 */           animInfo.currentFrame = 0.0F;
/* 202 */           return true;
/*     */         } 
/* 204 */         if (clientChannel.getAnimationMode() == EnumAnimationMode.HOLD) {
/* 205 */           animInfo.prevTime = currentTime;
/* 206 */           animInfo.currentFrame = channel.totalFrames - 1.0F;
/* 207 */           return true;
/*     */         } 
/* 209 */         return false;
/*     */       } 
/*     */       
/* 212 */       return true;
/*     */     } 
/*     */     
/* 215 */     animInfo.prevTime = currentTime;
/* 216 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isGamePaused() {
/* 227 */     Minecraft MC = Minecraft.func_71410_x();
/* 228 */     return (MC.func_71356_B() && MC.field_71462_r != null && MC.field_71462_r.func_73868_f() && !MC.func_71401_C().func_71344_c());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void performAnimationInModel(List<CSModelRenderer> parts, IAnimated animated) {
/* 241 */     for (CSModelRenderer entry : parts) {
/* 242 */       performAnimationForBlock(entry, animated);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void performAnimationForBlock(CSModelRenderer block, IAnimated animated) {
/* 254 */     String boxName = block.field_78802_n;
/*     */ 
/*     */     
/* 257 */     if (animated.getAnimationHandler() instanceof ClientAnimationHandler) {
/* 258 */       ClientAnimationHandler animHandler = (ClientAnimationHandler)animated.getAnimationHandler();
/*     */       
/* 260 */       if (block.field_78805_m != null) {
/* 261 */         for (int i = 0; i < block.field_78805_m.size(); i++) {
/* 262 */           ModelRenderer child = block.field_78805_m.get(i);
/* 263 */           if (child instanceof CSModelRenderer) {
/* 264 */             CSModelRenderer childModel = (CSModelRenderer)child;
/* 265 */             performAnimationForBlock(childModel, animated);
/*     */           } 
/*     */         } 
/*     */       }
/* 269 */       block.resetRotationPoint();
/* 270 */       block.resetRotationMatrix();
/* 271 */       block.resetOffset();
/* 272 */       block.resetStretch();
/*     */       
/* 274 */       Map<InfoChannel, AnimationHandler.AnimInfo> animInfoMap = (Map<InfoChannel, AnimationHandler.AnimInfo>)animHandler.currentAnimInfo.get(animated);
/* 275 */       if (animInfoMap == null) {
/*     */         return;
/*     */       }
/* 278 */       for (Map.Entry<InfoChannel, AnimationHandler.AnimInfo> animInfo : animInfoMap.entrySet()) {
/* 279 */         if (animInfo.getKey() instanceof ClientChannel) {
/* 280 */           ClientChannel clientChannel = (ClientChannel)animInfo.getKey();
/* 281 */           float currentFrame = ((AnimationHandler.AnimInfo)animInfo.getValue()).currentFrame;
/*     */ 
/*     */           
/* 284 */           KeyFrame prevRotationKeyFrame = clientChannel.getPreviousRotationKeyFrameForBox(boxName, currentFrame);
/* 285 */           int prevRotationKeyFramePosition = (prevRotationKeyFrame != null) ? clientChannel.getKeyFramePosition(prevRotationKeyFrame) : 0;
/*     */           
/* 287 */           KeyFrame nextRotationKeyFrame = clientChannel.getNextRotationKeyFrameForBox(boxName, currentFrame);
/* 288 */           int nextRotationKeyFramePosition = (nextRotationKeyFrame != null) ? clientChannel.getKeyFramePosition(nextRotationKeyFrame) : 0;
/*     */           
/* 290 */           float SLERPProgress = (currentFrame - prevRotationKeyFramePosition) / (nextRotationKeyFramePosition - prevRotationKeyFramePosition);
/*     */           
/* 292 */           if (SLERPProgress > 1.0F || SLERPProgress < 0.0F) {
/* 293 */             SLERPProgress = 1.0F;
/*     */           }
/* 295 */           if (prevRotationKeyFramePosition == 0 && prevRotationKeyFrame == null && nextRotationKeyFramePosition != 0) {
/* 296 */             Quat4f currentQuat = new Quat4f();
/* 297 */             currentQuat.interpolate(block.getDefaultRotationAsQuaternion(), nextRotationKeyFrame.modelRenderersRotations.get(boxName), SLERPProgress);
/*     */             
/* 299 */             Matrix4f mat = block.getRotationMatrix();
/* 300 */             mat.set(currentQuat);
/* 301 */             mat.transpose();
/*     */           }
/* 303 */           else if (nextRotationKeyFramePosition != 0) {
/* 304 */             Quat4f currentQuat = new Quat4f();
/* 305 */             currentQuat.interpolate(prevRotationKeyFrame.modelRenderersRotations.get(boxName), nextRotationKeyFrame.modelRenderersRotations
/* 306 */                 .get(boxName), SLERPProgress);
/* 307 */             Matrix4f mat = block.getRotationMatrix();
/* 308 */             mat.set(currentQuat);
/* 309 */             mat.transpose();
/*     */           } 
/*     */ 
/*     */           
/* 313 */           KeyFrame prevTranslationKeyFrame = clientChannel.getPreviousTranslationKeyFrameForBox(boxName, currentFrame);
/*     */           
/* 315 */           int prevTranslationsKeyFramePosition = (prevTranslationKeyFrame != null) ? clientChannel.getKeyFramePosition(prevTranslationKeyFrame) : 0;
/*     */           
/* 317 */           KeyFrame nextTranslationKeyFrame = clientChannel.getNextTranslationKeyFrameForBox(boxName, currentFrame);
/*     */           
/* 319 */           int nextTranslationsKeyFramePosition = (nextTranslationKeyFrame != null) ? clientChannel.getKeyFramePosition(nextTranslationKeyFrame) : 0;
/*     */           
/* 321 */           float LERPProgress = (currentFrame - prevTranslationsKeyFramePosition) / (nextTranslationsKeyFramePosition - prevTranslationsKeyFramePosition);
/*     */           
/* 323 */           if (LERPProgress > 1.0F || LERPProgress < 0.0F) {
/* 324 */             LERPProgress = 1.0F;
/*     */           }
/* 326 */           if (prevTranslationsKeyFramePosition == 0 && prevTranslationKeyFrame == null && nextTranslationsKeyFramePosition != 0) {
/* 327 */             Vector3f startPosition = block.getPositionAsVector();
/* 328 */             Vector3f endPosition = nextTranslationKeyFrame.modelRenderersTranslations.get(boxName);
/* 329 */             Vector3f currentPosition = new Vector3f(startPosition);
/* 330 */             currentPosition.interpolate((Tuple3f)endPosition, LERPProgress);
/* 331 */             block.func_78793_a(currentPosition.x, currentPosition.y, currentPosition.z);
/*     */           }
/* 333 */           else if (nextTranslationsKeyFramePosition != 0) {
/* 334 */             Vector3f startPosition = prevTranslationKeyFrame.modelRenderersTranslations.get(boxName);
/* 335 */             Vector3f endPosition = nextTranslationKeyFrame.modelRenderersTranslations.get(boxName);
/* 336 */             Vector3f currentPosition = new Vector3f(startPosition);
/* 337 */             currentPosition.interpolate((Tuple3f)endPosition, LERPProgress);
/* 338 */             block.func_78793_a(currentPosition.x, currentPosition.y, currentPosition.z);
/*     */           } 
/*     */ 
/*     */           
/* 342 */           KeyFrame prevOffsetKeyFrame = clientChannel.getPreviousOffsetKeyFrameForBox(boxName, currentFrame);
/* 343 */           int prevOffsetKeyFramePosition = (prevOffsetKeyFrame != null) ? clientChannel.getKeyFramePosition(prevOffsetKeyFrame) : 0;
/*     */           
/* 345 */           KeyFrame nextOffsetKeyFrame = clientChannel.getNextOffsetKeyFrameForBox(boxName, currentFrame);
/* 346 */           int nextOffsetKeyFramePosition = (nextOffsetKeyFrame != null) ? clientChannel.getKeyFramePosition(nextOffsetKeyFrame) : 0;
/*     */           
/* 348 */           float OffProgress = (currentFrame - prevOffsetKeyFramePosition) / (nextOffsetKeyFramePosition - prevOffsetKeyFramePosition);
/* 349 */           if (OffProgress > 1.0F || OffProgress < 0.0F) {
/* 350 */             OffProgress = 1.0F;
/*     */           }
/* 352 */           if (prevOffsetKeyFramePosition == 0 && prevOffsetKeyFrame == null && nextOffsetKeyFramePosition != 0) {
/* 353 */             Vector3f startPosition = block.getOffsetAsVector();
/* 354 */             Vector3f endPosition = nextOffsetKeyFrame.modelRenderersOffsets.get(boxName);
/* 355 */             Vector3f currentPosition = new Vector3f(startPosition);
/* 356 */             currentPosition.interpolate((Tuple3f)endPosition, OffProgress);
/* 357 */             block.setOffset(currentPosition.x, currentPosition.y, currentPosition.z);
/*     */           }
/* 359 */           else if (nextOffsetKeyFramePosition != 0) {
/* 360 */             Vector3f startPosition = prevOffsetKeyFrame.modelRenderersOffsets.get(boxName);
/* 361 */             Vector3f endPosition = nextOffsetKeyFrame.modelRenderersOffsets.get(boxName);
/* 362 */             Vector3f currentPosition = new Vector3f(startPosition);
/* 363 */             currentPosition.interpolate((Tuple3f)endPosition, OffProgress);
/* 364 */             block.setOffset(currentPosition.x, currentPosition.y, currentPosition.z);
/*     */           } 
/*     */ 
/*     */           
/* 368 */           KeyFrame prevStretchKeyFrame = clientChannel.getPreviousStretchKeyFrameForBox(boxName, currentFrame);
/* 369 */           int prevStretchKeyFramePosition = (prevStretchKeyFrame != null) ? clientChannel.getKeyFramePosition(prevStretchKeyFrame) : 0;
/*     */           
/* 371 */           KeyFrame nextStretchKeyFrame = clientChannel.getNextStretchKeyFrameForBox(boxName, currentFrame);
/* 372 */           int nextStretchKeyFramePosition = (nextStretchKeyFrame != null) ? clientChannel.getKeyFramePosition(nextStretchKeyFrame) : 0;
/*     */           
/* 374 */           float strProgress = (currentFrame - prevStretchKeyFramePosition) / (nextStretchKeyFramePosition - prevStretchKeyFramePosition);
/* 375 */           if (strProgress > 1.0F || strProgress < 0.0F) {
/* 376 */             strProgress = 1.0F;
/*     */           }
/* 378 */           if (prevStretchKeyFramePosition == 0 && prevStretchKeyFrame == null && nextStretchKeyFramePosition != 0) {
/* 379 */             Vector3f startPosition = block.getStretchAsVector();
/* 380 */             Vector3f endPosition = nextStretchKeyFrame.modelRenderersStretchs.get(boxName);
/* 381 */             Vector3f currentPosition = new Vector3f(startPosition);
/* 382 */             currentPosition.interpolate((Tuple3f)endPosition, strProgress);
/* 383 */             block.setStretch(currentPosition.x, currentPosition.y, currentPosition.z); continue;
/*     */           } 
/* 385 */           if (nextStretchKeyFramePosition != 0) {
/* 386 */             Vector3f startPosition = prevStretchKeyFrame.modelRenderersStretchs.get(boxName);
/* 387 */             Vector3f endPosition = nextStretchKeyFrame.modelRenderersStretchs.get(boxName);
/* 388 */             Vector3f currentPosition = new Vector3f(startPosition);
/* 389 */             currentPosition.interpolate((Tuple3f)endPosition, strProgress);
/* 390 */             block.setStretch(currentPosition.x, currentPosition.y, currentPosition.z);
/*     */           } 
/*     */           continue;
/*     */         } 
/* 394 */         if (animInfo.getKey() instanceof CustomChannel) {
/* 395 */           ((CustomChannel)animInfo.getKey()).update(block, animated);
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<T, Map<InfoChannel, AnimationHandler.AnimInfo>> getCurrentAnimInfo() {
/* 406 */     return this.currentAnimInfo;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCurrentAnimInfo(Map<T, Map<InfoChannel, AnimationHandler.AnimInfo>> currentAnimInfo) {
/* 416 */     this.currentAnimInfo = currentAnimInfo;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, InfoChannel> getAnimChannels() {
/* 425 */     return this.animChannels;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAnimChannels(Map<String, InfoChannel> animChannels) {
/* 435 */     this.animChannels = animChannels;
/*     */   }
/*     */ }


/* Location:              C:\Users\Josep\Downloads\tektopia-1.1.0-deobf.jar!\META-INF\libraries\CraftStudio-1.0.0.93-mc1.12-alpha.jar!\com\leviathanstudio\craftstudio\client\animation\ClientAnimationHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */