/*     */ package com.leviathanstudio.craftstudio.client.animation;
/*     */ 
/*     */ import com.leviathanstudio.craftstudio.common.animation.InfoChannel;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import net.minecraftforge.fml.relauncher.Side;
/*     */ import net.minecraftforge.fml.relauncher.SideOnly;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @SideOnly(Side.CLIENT)
/*     */ public class ClientChannel
/*     */   extends InfoChannel
/*     */ {
/*  23 */   private Map<Integer, KeyFrame> keyFrames = new HashMap<>();
/*     */ 
/*     */   
/*  26 */   private EnumAnimationMode animationMode = EnumAnimationMode.LINEAR;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ClientChannel(String channelName, boolean initialize) {
/*  37 */     super(channelName);
/*  38 */     if (initialize) {
/*  39 */       initializeAllFrames();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ClientChannel(String animationName, float fps, int totalFrames, EnumAnimationMode animationMode, boolean initialize) {
/*  57 */     this(animationName, initialize);
/*  58 */     this.fps = fps;
/*  59 */     this.totalFrames = totalFrames;
/*  60 */     setAnimationMode(animationMode);
/*  61 */     if (animationMode == EnumAnimationMode.LOOP) {
/*  62 */       this.looped = true;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void initializeAllFrames() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public KeyFrame getPreviousRotationKeyFrameForBox(String boxName, float currentFrame) {
/*  80 */     int latestFramePosition = -1;
/*  81 */     int lastFramePosition = -1;
/*  82 */     KeyFrame latestKeyFrame = null;
/*  83 */     for (Map.Entry<Integer, KeyFrame> entry : this.keyFrames.entrySet()) {
/*  84 */       Integer key = entry.getKey();
/*  85 */       KeyFrame value = entry.getValue();
/*     */       
/*  87 */       if (key.intValue() <= currentFrame && key.intValue() > latestFramePosition && 
/*  88 */         value.useBoxInRotations(boxName)) {
/*  89 */         latestFramePosition = key.intValue();
/*  90 */         latestKeyFrame = value;
/*     */       } 
/*  92 */       if (key.intValue() > lastFramePosition && value.useBoxInRotations(boxName))
/*  93 */         lastFramePosition = key.intValue(); 
/*     */     } 
/*  95 */     if (latestKeyFrame == null && lastFramePosition >= 0) {
/*  96 */       this.keyFrames.put(Integer.valueOf(lastFramePosition - this.totalFrames), ((KeyFrame)this.keyFrames.get(Integer.valueOf(lastFramePosition))).clone());
/*  97 */       latestKeyFrame = this.keyFrames.get(Integer.valueOf(lastFramePosition - this.totalFrames));
/*     */     } 
/*     */     
/* 100 */     return latestKeyFrame;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public KeyFrame getNextRotationKeyFrameForBox(String boxName, float currentFrame) {
/* 115 */     int nextFramePosition = -1;
/* 116 */     int firstFramePosition = this.totalFrames + 1;
/* 117 */     KeyFrame nextKeyFrame = null;
/* 118 */     if (currentFrame > this.totalFrames)
/* 119 */       return this.keyFrames.get(Integer.valueOf(this.totalFrames)); 
/* 120 */     for (Map.Entry<Integer, KeyFrame> entry : this.keyFrames.entrySet()) {
/* 121 */       Integer key = entry.getKey();
/* 122 */       KeyFrame value = entry.getValue();
/*     */       
/* 124 */       if (key.intValue() > currentFrame && (key.intValue() < nextFramePosition || nextFramePosition == -1) && 
/* 125 */         value.useBoxInRotations(boxName)) {
/* 126 */         nextFramePosition = key.intValue();
/* 127 */         nextKeyFrame = value;
/*     */       } 
/* 129 */       if (key.intValue() < firstFramePosition && value.useBoxInRotations(boxName))
/* 130 */         firstFramePosition = key.intValue(); 
/*     */     } 
/* 132 */     if (nextKeyFrame == null && firstFramePosition < this.totalFrames + 1) {
/* 133 */       this.keyFrames.put(Integer.valueOf(this.totalFrames + firstFramePosition), ((KeyFrame)this.keyFrames.get(Integer.valueOf(firstFramePosition))).clone());
/* 134 */       nextKeyFrame = this.keyFrames.get(Integer.valueOf(this.totalFrames + firstFramePosition));
/*     */     } 
/* 136 */     return nextKeyFrame;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public KeyFrame getPreviousTranslationKeyFrameForBox(String boxName, float currentFrame) {
/* 151 */     int latestFramePosition = -1;
/* 152 */     int lastFramePosition = -1;
/* 153 */     KeyFrame latestKeyFrame = null;
/* 154 */     for (Map.Entry<Integer, KeyFrame> entry : this.keyFrames.entrySet()) {
/* 155 */       Integer key = entry.getKey();
/* 156 */       KeyFrame value = entry.getValue();
/*     */       
/* 158 */       if (key.intValue() <= currentFrame && key.intValue() > latestFramePosition && 
/* 159 */         value.useBoxInTranslations(boxName)) {
/* 160 */         latestFramePosition = key.intValue();
/* 161 */         latestKeyFrame = value;
/*     */       } 
/* 163 */       if (key.intValue() > lastFramePosition && value.useBoxInTranslations(boxName))
/* 164 */         lastFramePosition = key.intValue(); 
/*     */     } 
/* 166 */     if (latestKeyFrame == null && lastFramePosition >= 0) {
/* 167 */       this.keyFrames.put(Integer.valueOf(lastFramePosition - this.totalFrames), ((KeyFrame)this.keyFrames.get(Integer.valueOf(lastFramePosition))).clone());
/* 168 */       latestKeyFrame = this.keyFrames.get(Integer.valueOf(lastFramePosition - this.totalFrames));
/*     */     } 
/*     */     
/* 171 */     return latestKeyFrame;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public KeyFrame getNextTranslationKeyFrameForBox(String boxName, float currentFrame) {
/* 186 */     int nextFramePosition = -1;
/* 187 */     int firstFramePosition = this.totalFrames + 1;
/* 188 */     KeyFrame nextKeyFrame = null;
/* 189 */     if (currentFrame > this.totalFrames)
/* 190 */       return this.keyFrames.get(Integer.valueOf(this.totalFrames)); 
/* 191 */     for (Map.Entry<Integer, KeyFrame> entry : this.keyFrames.entrySet()) {
/* 192 */       Integer key = entry.getKey();
/* 193 */       KeyFrame value = entry.getValue();
/*     */       
/* 195 */       if (key.intValue() > currentFrame && (key.intValue() < nextFramePosition || nextFramePosition == -1) && 
/* 196 */         value.useBoxInTranslations(boxName)) {
/* 197 */         nextFramePosition = key.intValue();
/* 198 */         nextKeyFrame = value;
/*     */       } 
/* 200 */       if (key.intValue() < firstFramePosition && value.useBoxInTranslations(boxName))
/* 201 */         firstFramePosition = key.intValue(); 
/*     */     } 
/* 203 */     if (nextKeyFrame == null && firstFramePosition < this.totalFrames + 1) {
/* 204 */       this.keyFrames.put(Integer.valueOf(this.totalFrames + firstFramePosition), ((KeyFrame)this.keyFrames.get(Integer.valueOf(firstFramePosition))).clone());
/* 205 */       nextKeyFrame = this.keyFrames.get(Integer.valueOf(this.totalFrames + firstFramePosition));
/*     */     } 
/*     */     
/* 208 */     return nextKeyFrame;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public KeyFrame getPreviousOffsetKeyFrameForBox(String boxName, float currentFrame) {
/* 223 */     int latestFramePosition = -1;
/* 224 */     int lastFramePosition = -1;
/* 225 */     KeyFrame latestKeyFrame = null;
/* 226 */     for (Map.Entry<Integer, KeyFrame> entry : this.keyFrames.entrySet()) {
/* 227 */       Integer key = entry.getKey();
/* 228 */       KeyFrame value = entry.getValue();
/*     */       
/* 230 */       if (key.intValue() <= currentFrame && key.intValue() > latestFramePosition && 
/* 231 */         value.useBoxInOffsets(boxName)) {
/* 232 */         latestFramePosition = key.intValue();
/* 233 */         latestKeyFrame = value;
/*     */       } 
/* 235 */       if (key.intValue() > lastFramePosition && value.useBoxInOffsets(boxName))
/* 236 */         lastFramePosition = key.intValue(); 
/*     */     } 
/* 238 */     if (latestKeyFrame == null && lastFramePosition >= 0) {
/* 239 */       this.keyFrames.put(Integer.valueOf(lastFramePosition - this.totalFrames), ((KeyFrame)this.keyFrames.get(Integer.valueOf(lastFramePosition))).clone());
/* 240 */       latestKeyFrame = this.keyFrames.get(Integer.valueOf(lastFramePosition - this.totalFrames));
/*     */     } 
/*     */     
/* 243 */     return latestKeyFrame;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public KeyFrame getNextOffsetKeyFrameForBox(String boxName, float currentFrame) {
/* 258 */     int nextFramePosition = -1;
/* 259 */     int firstFramePosition = this.totalFrames + 1;
/* 260 */     KeyFrame nextKeyFrame = null;
/* 261 */     if (currentFrame > this.totalFrames)
/* 262 */       return this.keyFrames.get(Integer.valueOf(this.totalFrames)); 
/* 263 */     for (Map.Entry<Integer, KeyFrame> entry : this.keyFrames.entrySet()) {
/* 264 */       Integer key = entry.getKey();
/* 265 */       KeyFrame value = entry.getValue();
/*     */       
/* 267 */       if (key.intValue() > currentFrame && (key.intValue() < nextFramePosition || nextFramePosition == -1) && 
/* 268 */         value.useBoxInOffsets(boxName)) {
/* 269 */         nextFramePosition = key.intValue();
/* 270 */         nextKeyFrame = value;
/*     */       } 
/* 272 */       if (key.intValue() < firstFramePosition && value.useBoxInOffsets(boxName))
/* 273 */         firstFramePosition = key.intValue(); 
/*     */     } 
/* 275 */     if (nextKeyFrame == null && firstFramePosition < this.totalFrames + 1) {
/* 276 */       this.keyFrames.put(Integer.valueOf(this.totalFrames + firstFramePosition), ((KeyFrame)this.keyFrames.get(Integer.valueOf(firstFramePosition))).clone());
/* 277 */       nextKeyFrame = this.keyFrames.get(Integer.valueOf(this.totalFrames + firstFramePosition));
/*     */     } 
/*     */     
/* 280 */     return nextKeyFrame;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public KeyFrame getPreviousStretchKeyFrameForBox(String boxName, float currentFrame) {
/* 295 */     int latestFramePosition = -1;
/* 296 */     int lastFramePosition = -1;
/* 297 */     KeyFrame latestKeyFrame = null;
/* 298 */     for (Map.Entry<Integer, KeyFrame> entry : this.keyFrames.entrySet()) {
/* 299 */       Integer key = entry.getKey();
/* 300 */       KeyFrame value = entry.getValue();
/*     */       
/* 302 */       if (key.intValue() <= currentFrame && key.intValue() > latestFramePosition && 
/* 303 */         value.useBoxInStretchs(boxName)) {
/* 304 */         latestFramePosition = key.intValue();
/* 305 */         latestKeyFrame = value;
/*     */       } 
/* 307 */       if (key.intValue() > lastFramePosition && value.useBoxInStretchs(boxName))
/* 308 */         lastFramePosition = key.intValue(); 
/*     */     } 
/* 310 */     if (latestKeyFrame == null && lastFramePosition >= 0) {
/* 311 */       this.keyFrames.put(Integer.valueOf(lastFramePosition - this.totalFrames), ((KeyFrame)this.keyFrames.get(Integer.valueOf(lastFramePosition))).clone());
/* 312 */       latestKeyFrame = this.keyFrames.get(Integer.valueOf(lastFramePosition - this.totalFrames));
/*     */     } 
/*     */     
/* 315 */     return latestKeyFrame;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public KeyFrame getNextStretchKeyFrameForBox(String boxName, float currentFrame) {
/* 330 */     int nextFramePosition = -1;
/* 331 */     int firstFramePosition = this.totalFrames + 1;
/* 332 */     KeyFrame nextKeyFrame = null;
/* 333 */     if (currentFrame > this.totalFrames)
/* 334 */       return this.keyFrames.get(Integer.valueOf(this.totalFrames)); 
/* 335 */     for (Map.Entry<Integer, KeyFrame> entry : this.keyFrames.entrySet()) {
/* 336 */       Integer key = entry.getKey();
/* 337 */       KeyFrame value = entry.getValue();
/*     */       
/* 339 */       if (key.intValue() > currentFrame && (key.intValue() < nextFramePosition || nextFramePosition == -1) && 
/* 340 */         value.useBoxInStretchs(boxName)) {
/* 341 */         nextFramePosition = key.intValue();
/* 342 */         nextKeyFrame = value;
/*     */       } 
/* 344 */       if (key.intValue() < firstFramePosition && value.useBoxInStretchs(boxName))
/* 345 */         firstFramePosition = key.intValue(); 
/*     */     } 
/* 347 */     if (nextKeyFrame == null && firstFramePosition < this.totalFrames + 1) {
/* 348 */       this.keyFrames.put(Integer.valueOf(this.totalFrames + firstFramePosition), ((KeyFrame)this.keyFrames.get(Integer.valueOf(firstFramePosition))).clone());
/* 349 */       nextKeyFrame = this.keyFrames.get(Integer.valueOf(this.totalFrames + firstFramePosition));
/*     */     } 
/*     */     
/* 352 */     return nextKeyFrame;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getKeyFramePosition(KeyFrame keyFrame) {
/* 364 */     if (keyFrame != null)
/* 365 */       for (Map.Entry<Integer, KeyFrame> entry : this.keyFrames.entrySet()) {
/* 366 */         Integer key = entry.getKey();
/* 367 */         KeyFrame keyframe = entry.getValue();
/*     */         
/* 369 */         if (keyframe == keyFrame)
/* 370 */           return key.intValue(); 
/*     */       }  
/* 372 */     return -1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ClientChannel getInvertedChannel(String name) {
/* 383 */     ClientChannel chan = new ClientChannel(name, this.fps, this.totalFrames, getAnimationMode(), true);
/* 384 */     for (Map.Entry<Integer, KeyFrame> entry : this.keyFrames.entrySet())
/* 385 */       chan.keyFrames.put(Integer.valueOf(this.totalFrames - ((Integer)entry.getKey()).intValue()), ((KeyFrame)entry.getValue()).clone()); 
/* 386 */     return chan;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<Integer, KeyFrame> getKeyFrames() {
/* 395 */     return this.keyFrames;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setKeyFrames(Map<Integer, KeyFrame> keyFrames) {
/* 405 */     this.keyFrames = keyFrames;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public EnumAnimationMode getAnimationMode() {
/* 414 */     return this.animationMode;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAnimationMode(EnumAnimationMode animationMode) {
/* 424 */     this.animationMode = animationMode;
/*     */   }
/*     */ }


/* Location:              C:\Users\Josep\Downloads\tektopia-1.1.0-deobf.jar!\META-INF\libraries\CraftStudio-1.0.0.93-mc1.12-alpha.jar!\com\leviathanstudio\craftstudio\client\animation\ClientChannel.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */