/*     */ package com.leviathanstudio.craftstudio.client.animation;
/*     */ 
/*     */ import com.leviathanstudio.craftstudio.CraftStudioApi;
/*     */ import com.leviathanstudio.craftstudio.client.exception.CSResourceNotRegisteredException;
/*     */ import com.leviathanstudio.craftstudio.client.json.CSReadedAnim;
/*     */ import com.leviathanstudio.craftstudio.client.json.CSReadedAnimBlock;
/*     */ import com.leviathanstudio.craftstudio.client.json.CSReadedModel;
/*     */ import com.leviathanstudio.craftstudio.client.json.CSReadedModelBlock;
/*     */ import com.leviathanstudio.craftstudio.client.registry.RegistryHandler;
/*     */ import com.leviathanstudio.craftstudio.client.util.MathHelper;
/*     */ import java.util.Map;
/*     */ import javax.vecmath.Tuple3f;
/*     */ import javax.vecmath.Vector3f;
/*     */ import net.minecraft.util.ResourceLocation;
/*     */ import net.minecraftforge.fml.relauncher.Side;
/*     */ import net.minecraftforge.fml.relauncher.SideOnly;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @SideOnly(Side.CLIENT)
/*     */ public class CSAnimChannel
/*     */   extends ClientChannel
/*     */ {
/*     */   private CSReadedAnim rAnim;
/*     */   private CSReadedModel rModel;
/*     */   
/*     */   public CSAnimChannel(ResourceLocation animIn, ResourceLocation modelIn, boolean looped) throws CSResourceNotRegisteredException {
/*  50 */     this(animIn, modelIn, 60.0F, looped);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CSAnimChannel(ResourceLocation animIn, ResourceLocation modelIn, float fps, boolean looped) throws CSResourceNotRegisteredException {
/*  70 */     super(animIn.toString(), false);
/*  71 */     this.rAnim = (CSReadedAnim)RegistryHandler.animationRegistry.func_82594_a(animIn);
/*  72 */     if (this.rAnim == null)
/*  73 */       throw new CSResourceNotRegisteredException(animIn.toString()); 
/*  74 */     this.rModel = (CSReadedModel)RegistryHandler.modelRegistry.func_82594_a(modelIn);
/*  75 */     if (this.rModel == null)
/*  76 */       throw new CSResourceNotRegisteredException(modelIn.toString()); 
/*  77 */     if (!this.rModel.isAnimable()) {
/*  78 */       CraftStudioApi.getLogger().warn("You are trying to animate the model \"" + modelIn.toString() + "\"");
/*  79 */       CraftStudioApi.getLogger().warn("But it contains at least two blocks with the name \"" + this.rModel.whyUnAnimable() + "\"");
/*  80 */       CraftStudioApi.getLogger().warn("There could be weird result with your animation");
/*     */     } 
/*  82 */     this.fps = fps;
/*  83 */     this.totalFrames = this.rAnim.getDuration();
/*  84 */     if (looped) {
/*  85 */       setAnimationMode(EnumAnimationMode.LOOP);
/*  86 */     } else if (this.rAnim.isHoldLastK()) {
/*  87 */       setAnimationMode(EnumAnimationMode.HOLD);
/*  88 */     }  initializeAllFrames();
/*     */   }
/*     */ 
/*     */   
/*     */   protected void initializeAllFrames() {
/*     */     Integer[] arrayOfInteger;
/*     */     int i;
/*     */     byte b;
/*  96 */     for (arrayOfInteger = this.rAnim.getKeyFrames(), i = arrayOfInteger.length, b = 0; b < i; ) { int j = arrayOfInteger[b].intValue();
/*  97 */       getKeyFrames().put(Integer.valueOf(j), new KeyFrame()); b++; }
/*  98 */      if (this.rAnim.isHoldLastK() && 
/*  99 */       !getKeyFrames().containsKey(Integer.valueOf(this.totalFrames)))
/* 100 */       getKeyFrames().put(Integer.valueOf(this.totalFrames), new KeyFrame()); 
/* 101 */     for (CSReadedAnimBlock block : this.rAnim.getBlocks()) {
/* 102 */       CSReadedModelBlock mBlock = this.rModel.getBlockFromName(block.getName());
/* 103 */       int lastRK = 0;
/* 104 */       int lastTK = 0;
/* 105 */       int lastOK = 0;
/* 106 */       int lastSK = 0;
/* 107 */       if (mBlock != null) {
/* 108 */         for (Map.Entry<Integer, CSReadedAnimBlock.ReadedKeyFrame> entry : (Iterable<Map.Entry<Integer, CSReadedAnimBlock.ReadedKeyFrame>>)block.getKeyFrames().entrySet()) {
/*     */           
/* 110 */           KeyFrame keyFrame = getKeyFrames().get(entry.getKey());
/* 111 */           CSReadedAnimBlock.ReadedKeyFrame rKeyFrame = entry.getValue();
/* 112 */           if (rKeyFrame.position != null) {
/* 113 */             Vector3f vector = new Vector3f(rKeyFrame.position);
/* 114 */             vector.add((Tuple3f)mBlock.getRotationPoint());
/* 115 */             keyFrame.modelRenderersTranslations.put(block.getName(), vector);
/* 116 */             if (lastTK < ((Integer)entry.getKey()).intValue())
/* 117 */               lastTK = ((Integer)entry.getKey()).intValue(); 
/*     */           } 
/* 119 */           if (rKeyFrame.rotation != null) {
/* 120 */             Vector3f vector = new Vector3f(rKeyFrame.rotation);
/* 121 */             vector.add((Tuple3f)mBlock.getRotation());
/* 122 */             keyFrame.modelRenderersRotations.put(block.getName(), MathHelper.quatFromEuler(vector));
/* 123 */             if (lastRK < ((Integer)entry.getKey()).intValue())
/* 124 */               lastRK = ((Integer)entry.getKey()).intValue(); 
/*     */           } 
/* 126 */           if (rKeyFrame.offset != null) {
/* 127 */             Vector3f vector = new Vector3f(rKeyFrame.offset);
/* 128 */             vector.add((Tuple3f)mBlock.getOffset());
/* 129 */             keyFrame.modelRenderersOffsets.put(block.getName(), vector);
/* 130 */             if (lastOK < ((Integer)entry.getKey()).intValue())
/* 131 */               lastOK = ((Integer)entry.getKey()).intValue(); 
/*     */           } 
/* 133 */           if (rKeyFrame.stretching != null) {
/* 134 */             Vector3f vector = new Vector3f(rKeyFrame.stretching);
/* 135 */             vector.add((Tuple3f)mBlock.getStretch());
/* 136 */             keyFrame.modelRenderersStretchs.put(block.getName(), vector);
/* 137 */             if (lastSK < ((Integer)entry.getKey()).intValue())
/* 138 */               lastSK = ((Integer)entry.getKey()).intValue(); 
/*     */           } 
/*     */         } 
/*     */       } else {
/* 142 */         System.out.println("The block " + block.getName() + " doesn't exist in model " + this.rModel.getName() + " !");
/* 143 */       }  if (this.rAnim.isHoldLastK()) {
/* 144 */         if (lastTK != 0)
/* 145 */           ((KeyFrame)getKeyFrames().get(Integer.valueOf(this.totalFrames))).modelRenderersTranslations.put(block.getName(), ((KeyFrame)
/* 146 */               getKeyFrames().get(Integer.valueOf(lastTK))).modelRenderersTranslations.get(block.getName())); 
/* 147 */         if (lastRK != 0)
/* 148 */           ((KeyFrame)getKeyFrames().get(Integer.valueOf(this.totalFrames))).modelRenderersRotations.put(block.getName(), ((KeyFrame)
/* 149 */               getKeyFrames().get(Integer.valueOf(lastRK))).modelRenderersRotations.get(block.getName())); 
/* 150 */         if (lastOK != 0)
/* 151 */           ((KeyFrame)getKeyFrames().get(Integer.valueOf(this.totalFrames))).modelRenderersOffsets.put(block.getName(), ((KeyFrame)
/* 152 */               getKeyFrames().get(Integer.valueOf(lastOK))).modelRenderersOffsets.get(block.getName())); 
/* 153 */         if (lastSK != 0)
/* 154 */           ((KeyFrame)getKeyFrames().get(Integer.valueOf(this.totalFrames))).modelRenderersStretchs.put(block.getName(), ((KeyFrame)
/* 155 */               getKeyFrames().get(Integer.valueOf(lastSK))).modelRenderersStretchs.get(block.getName())); 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\Josep\Downloads\tektopia-1.1.0-deobf.jar!\META-INF\libraries\CraftStudio-1.0.0.93-mc1.12-alpha.jar!\com\leviathanstudio\craftstudio\client\animation\CSAnimChannel.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */