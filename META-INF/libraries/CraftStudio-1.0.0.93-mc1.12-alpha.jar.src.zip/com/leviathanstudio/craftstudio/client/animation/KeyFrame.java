/*    */ package com.leviathanstudio.craftstudio.client.animation;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import javax.vecmath.Quat4f;
/*    */ import javax.vecmath.Vector3f;
/*    */ import net.minecraftforge.fml.relauncher.Side;
/*    */ import net.minecraftforge.fml.relauncher.SideOnly;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @SideOnly(Side.CLIENT)
/*    */ public class KeyFrame
/*    */   implements Cloneable
/*    */ {
/* 24 */   protected Map<String, Quat4f> modelRenderersRotations = new HashMap<>();
/*    */   
/* 26 */   protected Map<String, Vector3f> modelRenderersTranslations = new HashMap<>();
/*    */   
/* 28 */   protected Map<String, Vector3f> modelRenderersOffsets = new HashMap<>();
/*    */   
/* 30 */   protected Map<String, Vector3f> modelRenderersStretchs = new HashMap<>();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean useBoxInRotations(String boxName) {
/* 40 */     return (this.modelRenderersRotations.get(boxName) != null);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean useBoxInTranslations(String boxName) {
/* 51 */     return (this.modelRenderersTranslations.get(boxName) != null);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean useBoxInOffsets(String boxName) {
/* 62 */     return (this.modelRenderersOffsets.get(boxName) != null);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean useBoxInStretchs(String boxName) {
/* 73 */     return (this.modelRenderersStretchs.get(boxName) != null);
/*    */   }
/*    */ 
/*    */   
/*    */   public KeyFrame clone() {
/* 78 */     KeyFrame kf = new KeyFrame();
/* 79 */     kf.modelRenderersRotations = this.modelRenderersRotations;
/* 80 */     kf.modelRenderersTranslations = this.modelRenderersTranslations;
/* 81 */     kf.modelRenderersOffsets = this.modelRenderersOffsets;
/* 82 */     kf.modelRenderersStretchs = this.modelRenderersStretchs;
/* 83 */     return kf;
/*    */   }
/*    */ }


/* Location:              C:\Users\Josep\Downloads\tektopia-1.1.0-deobf.jar!\META-INF\libraries\CraftStudio-1.0.0.93-mc1.12-alpha.jar!\com\leviathanstudio\craftstudio\client\animation\KeyFrame.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */