/*     */ package com.leviathanstudio.craftstudio.client.model;
/*     */ 
/*     */ import net.minecraft.client.model.ModelRenderer;
/*     */ import net.minecraft.client.model.PositionTextureVertex;
/*     */ import net.minecraft.client.model.TexturedQuad;
/*     */ import net.minecraft.client.renderer.BufferBuilder;
/*     */ import net.minecraft.util.math.Vec3d;
/*     */ import net.minecraftforge.fml.relauncher.Side;
/*     */ import net.minecraftforge.fml.relauncher.SideOnly;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @SideOnly(Side.CLIENT)
/*     */ public class CSModelBox
/*     */ {
/*     */   private final TexturedQuad[] quadList;
/*     */   public String boxName;
/*     */   private static final double NORM_PREC = 1.0E-4D;
/*     */   
/*     */   public CSModelBox(ModelRenderer renderer, int texU, int texV, float x, float y, float z, float dx, float dy, float dz) {
/*  54 */     this(renderer, texU, texV, x, y, z, dx, dy, dz, renderer.field_78809_i);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CSModelBox(ModelRenderer renderer, int texU, int texV, float x, float y, float z, float dx, float dy, float dz, boolean mirror) {
/*  82 */     this(renderer, getVerticesForRect(x, y, z, dx, dy, dz, mirror), getTextureUVsForRect(texU, texV, dx, dy, dz), mirror);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CSModelBox(ModelRenderer renderer, PositionTextureVertex[] positionTextureVertex, int[][] textUVs) {
/* 100 */     this(renderer, positionTextureVertex, textUVs, renderer.field_78809_i);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CSModelBox(ModelRenderer renderer, PositionTextureVertex[] positionTextureVertex, int[][] textUVs, boolean mirror) {
/* 119 */     this(positionTextureVertex);
/* 120 */     setTexture(renderer, textUVs);
/* 121 */     checkBlockForShadow();
/* 122 */     if (mirror) {
/* 123 */       for (TexturedQuad texturedquad : this.quadList) {
/* 124 */         texturedquad.func_78235_a();
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CSModelBox(PositionTextureVertex[] positionTextureVertex) {
/* 135 */     this(6);
/* 136 */     setVertex(positionTextureVertex);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CSModelBox(int facesNumber) {
/* 146 */     this.quadList = new TexturedQuad[facesNumber];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setVertex(PositionTextureVertex[] positionTextureVertex) {
/* 168 */     if (positionTextureVertex.length == 8) {
/* 169 */       this.quadList[0] = new TexturedQuad(new PositionTextureVertex[] { positionTextureVertex[5], positionTextureVertex[1], positionTextureVertex[2], positionTextureVertex[6] });
/*     */       
/* 171 */       this.quadList[1] = new TexturedQuad(new PositionTextureVertex[] { positionTextureVertex[0], positionTextureVertex[4], positionTextureVertex[7], positionTextureVertex[3] });
/*     */       
/* 173 */       this.quadList[2] = new TexturedQuad(new PositionTextureVertex[] { positionTextureVertex[5], positionTextureVertex[4], positionTextureVertex[0], positionTextureVertex[1] });
/*     */       
/* 175 */       this.quadList[3] = new TexturedQuad(new PositionTextureVertex[] { positionTextureVertex[2], positionTextureVertex[3], positionTextureVertex[7], positionTextureVertex[6] });
/*     */       
/* 177 */       this.quadList[4] = new TexturedQuad(new PositionTextureVertex[] { positionTextureVertex[1], positionTextureVertex[0], positionTextureVertex[3], positionTextureVertex[2] });
/*     */       
/* 179 */       this.quadList[5] = new TexturedQuad(new PositionTextureVertex[] { positionTextureVertex[4], positionTextureVertex[5], positionTextureVertex[6], positionTextureVertex[7] });
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void checkBlockForShadow() {
/* 188 */     Vec3d or = ((this.quadList[1]).field_78239_a[0]).field_78243_a;
/* 189 */     double x = ((this.quadList[0]).field_78239_a[1]).field_78243_a.field_72450_a, y = ((this.quadList[1]).field_78239_a[3]).field_78243_a.field_72448_b;
/* 190 */     double z = ((this.quadList[1]).field_78239_a[1]).field_78243_a.field_72449_c;
/* 191 */     if (x - or.field_72450_a < 0.0D)
/* 192 */       flipFaces(); 
/* 193 */     if (y - or.field_72448_b > 0.0D)
/* 194 */       flipFaces(); 
/* 195 */     if (z - or.field_72449_c > 0.0D) {
/* 196 */       flipFaces();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void flipFaces() {
/* 203 */     for (int i = 0; i < this.quadList.length; i++) {
/* 204 */       this.quadList[i].func_78235_a();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTexture(ModelRenderer renderer, int[][] textUVs) {
/* 231 */     if (textUVs.length == 6) {
/* 232 */       for (int i = 0; i < 6; i++) {
/* 233 */         int[] textUV = textUVs[i];
/* 234 */         if (textUV.length == 4) {
/* 235 */           this.quadList[i] = new TexturedQuad((this.quadList[i]).field_78239_a, textUV[0], textUV[1], textUV[2], textUV[3], renderer.field_78801_a, renderer.field_78799_b);
/*     */         }
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static PositionTextureVertex[] getVerticesForRect(float x, float y, float z, float dx, float dy, float dz, boolean mirror) {
/* 261 */     PositionTextureVertex[] positionTextureVertex = new PositionTextureVertex[8];
/* 262 */     float endX = x + dx;
/* 263 */     float endY = y + dy;
/* 264 */     float endZ = z + dz;
/*     */     
/* 266 */     if (mirror) {
/* 267 */       float buffer = endX;
/* 268 */       endX = x;
/* 269 */       x = buffer;
/*     */     } 
/*     */     
/* 272 */     positionTextureVertex[0] = new PositionTextureVertex(x, y, z, 0.0F, 0.0F);
/* 273 */     positionTextureVertex[1] = new PositionTextureVertex(endX, y, z, 0.0F, 0.0F);
/* 274 */     positionTextureVertex[2] = new PositionTextureVertex(endX, endY, z, 0.0F, 0.0F);
/* 275 */     positionTextureVertex[3] = new PositionTextureVertex(x, endY, z, 0.0F, 0.0F);
/* 276 */     positionTextureVertex[4] = new PositionTextureVertex(x, y, endZ, 0.0F, 0.0F);
/* 277 */     positionTextureVertex[5] = new PositionTextureVertex(endX, y, endZ, 0.0F, 0.0F);
/* 278 */     positionTextureVertex[6] = new PositionTextureVertex(endX, endY, endZ, 0.0F, 0.0F);
/* 279 */     positionTextureVertex[7] = new PositionTextureVertex(x, endY, endZ, 0.0F, 0.0F);
/*     */     
/* 281 */     return positionTextureVertex;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int[][] getTextureUVsForRect(int texU, int texV, float dx, float dy, float dz) {
/* 301 */     dy = -dy;
/* 302 */     dz = -dz;
/* 303 */     int[][] tab = { { (int)(texU + dz + dx + dz), (int)(texV + dz + dy), (int)(texU + dz + dx), (int)(texV + dz) }, { (int)(texU + dz), (int)(texV + dz + dy), texU, (int)(texV + dz) }, { (int)(texU + dz + dx), texV, (int)(texU + dz + dx + dx), (int)(texV + dz) }, { (int)(texU + dz), texV, (int)(texU + dz + dx), (int)(texV + dz) }, { (int)(texU + dz + dx + dz + dx), (int)(texV + dz + dy), (int)(texU + dz + dx + dz), (int)(texV + dz) }, { (int)(texU + dz + dx), (int)(texV + dz + dy), (int)(texU + dz), (int)(texV + dz) } };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 309 */     return tab;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void render(BufferBuilder renderer, float scale) {
/* 321 */     for (TexturedQuad texturedquad : this.quadList) {
/* 322 */       texturedquad.func_178765_a(renderer, scale);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CSModelBox setBoxName(String name) {
/* 333 */     this.boxName = name;
/* 334 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TexturedQuad[] getQuadList() {
/* 343 */     return this.quadList;
/*     */   }
/*     */ }


/* Location:              C:\Users\Josep\Downloads\tektopia-1.1.0-deobf.jar!\META-INF\libraries\CraftStudio-1.0.0.93-mc1.12-alpha.jar!\com\leviathanstudio\craftstudio\client\model\CSModelBox.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */