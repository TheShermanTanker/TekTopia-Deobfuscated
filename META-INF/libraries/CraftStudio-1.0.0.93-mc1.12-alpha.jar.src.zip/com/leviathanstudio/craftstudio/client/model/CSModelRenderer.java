/*     */ package com.leviathanstudio.craftstudio.client.model;
/*     */ 
/*     */ import com.leviathanstudio.craftstudio.client.util.MathHelper;
/*     */ import java.nio.FloatBuffer;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import javax.vecmath.Matrix4f;
/*     */ import javax.vecmath.Quat4f;
/*     */ import javax.vecmath.Vector3f;
/*     */ import net.minecraft.client.model.ModelBase;
/*     */ import net.minecraft.client.model.ModelRenderer;
/*     */ import net.minecraft.client.model.PositionTextureVertex;
/*     */ import net.minecraft.client.renderer.BufferBuilder;
/*     */ import net.minecraft.client.renderer.GLAllocation;
/*     */ import net.minecraft.client.renderer.GlStateManager;
/*     */ import net.minecraft.client.renderer.Tessellator;
/*     */ import net.minecraftforge.fml.relauncher.Side;
/*     */ import net.minecraftforge.fml.relauncher.SideOnly;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @SideOnly(Side.CLIENT)
/*     */ public class CSModelRenderer
/*     */   extends ModelRenderer
/*     */ {
/*     */   private int textureOffsetX;
/*     */   private int textureOffsetY;
/*     */   private boolean compiled;
/*     */   private int displayList;
/*  47 */   public List<CSModelBox> cubeCSList = new ArrayList<>();
/*     */   
/*  49 */   private final Matrix4f rotationMatrix = new Matrix4f();
/*     */   
/*  51 */   private Matrix4f prevRotationMatrix = new Matrix4f();
/*     */   
/*  53 */   private Vector3f stretch = new Vector3f(1.0F, 1.0F, 1.0F);
/*     */   
/*     */   private float defaultRotationPointX;
/*     */   
/*     */   private float defaultRotationPointY;
/*     */   private float defaultRotationPointZ;
/*  59 */   private Matrix4f defaultRotationMatrix = new Matrix4f();
/*     */   private Quat4f defaultRotationAsQuaternion;
/*  61 */   private float defaultOffsetX = 0.0F;
/*  62 */   private float defaultOffsetY = 0.0F;
/*  63 */   private float defaultOffsetZ = 0.0F;
/*  64 */   private Vector3f defaultStretch = new Vector3f(1.0F, 1.0F, 1.0F);
/*     */   
/*     */   public CSModelRenderer(ModelBase modelbase, String partName, int xTextureOffset, int yTextureOffset) {
/*  67 */     super(modelbase, partName);
/*  68 */     func_78787_b(modelbase.field_78090_t, modelbase.field_78089_u);
/*  69 */     func_78784_a(xTextureOffset, yTextureOffset);
/*     */   }
/*     */ 
/*     */   
/*     */   public ModelRenderer func_78784_a(int x, int y) {
/*  74 */     this.textureOffsetX = x;
/*  75 */     this.textureOffsetY = y;
/*  76 */     this.field_78804_l.size();
/*  77 */     return this;
/*     */   }
/*     */   
/*     */   public ModelRenderer addBox(String name, CSModelBox modelBox) {
/*  81 */     name = this.field_78802_n + "." + name;
/*  82 */     this.cubeCSList.add(modelBox.setBoxName(name));
/*  83 */     return this;
/*     */   }
/*     */   
/*     */   public ModelRenderer addBox(String name, float par2, float par3, float par4, float par5, float par6, float par7) {
/*  87 */     name = this.field_78802_n + "." + name;
/*  88 */     this.cubeCSList.add((new CSModelBox(this, this.textureOffsetX, this.textureOffsetY, par2, par3, par4, par5, par6, par7)).setBoxName(name));
/*  89 */     return this;
/*     */   }
/*     */   
/*     */   public ModelRenderer addBox(float posX, float posY, float posZ, float sizeX, float sizeY, float sizeZ) {
/*  93 */     this.cubeCSList.add(new CSModelBox(this, this.textureOffsetX, this.textureOffsetY, posX, posY, posZ, sizeX, sizeY, sizeZ));
/*  94 */     return this;
/*     */   }
/*     */   
/*     */   public ModelRenderer addBox(float posX, float posY, float posZ, float sizeX, float sizeY, float sizeZ, boolean mirror) {
/*  98 */     this.cubeCSList.add(new CSModelBox(this, this.textureOffsetX, this.textureOffsetY, posX, posY, posZ, sizeX, sizeY, sizeZ, mirror));
/*  99 */     return this;
/*     */   }
/*     */   
/*     */   public ModelRenderer addBox(PositionTextureVertex[] positionTextureVertex, int[][] textUVs) {
/* 103 */     this.cubeCSList.add(new CSModelBox(this, positionTextureVertex, textUVs));
/* 104 */     return this;
/*     */   }
/*     */   
/*     */   public ModelRenderer addBox(PositionTextureVertex[] positionTextureVertex, int[][] textUVs, boolean mirror) {
/* 108 */     this.cubeCSList.add(new CSModelBox(this, positionTextureVertex, textUVs, mirror));
/* 109 */     return this;
/*     */   }
/*     */   
/*     */   public ModelRenderer addBox(CSModelBox model) {
/* 113 */     this.cubeCSList.add(model);
/* 114 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static CSModelRenderer getModelRendererFromNameAndBlock(String name, CSModelRenderer block) {
/* 120 */     if (block.field_78802_n.equals(name)) {
/* 121 */       return block;
/*     */     }
/* 123 */     for (ModelRenderer child : block.field_78805_m) {
/* 124 */       if (child instanceof CSModelRenderer) {
/* 125 */         CSModelRenderer childModel = (CSModelRenderer)child;
/* 126 */         CSModelRenderer result = getModelRendererFromNameAndBlock(name, childModel);
/* 127 */         if (result != null)
/* 128 */           return result; 
/*     */       } 
/*     */     } 
/* 131 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_78785_a(float scale) {
/* 139 */     if (!this.field_78807_k && 
/* 140 */       this.field_78806_j) {
/* 141 */       if (!this.compiled) {
/* 142 */         func_78788_d(scale);
/*     */       }
/* 144 */       GlStateManager.func_179094_E();
/*     */       
/* 146 */       GlStateManager.func_179109_b(this.field_78800_c * scale, this.field_78797_d * scale, this.field_78798_e * scale);
/* 147 */       FloatBuffer buf = MathHelper.makeFloatBuffer(this.rotationMatrix);
/* 148 */       GlStateManager.func_179110_a(buf);
/* 149 */       GlStateManager.func_179109_b(this.field_82906_o * scale, this.field_82908_p * scale, this.field_82907_q * scale);
/*     */       
/* 151 */       GlStateManager.func_179094_E();
/* 152 */       GlStateManager.func_179152_a(this.stretch.x, this.stretch.y, this.stretch.z);
/* 153 */       GlStateManager.func_179148_o(this.displayList);
/* 154 */       GlStateManager.func_179121_F();
/*     */       
/* 156 */       if (this.field_78805_m != null)
/* 157 */         for (int i = 0; i < this.field_78805_m.size(); i++) {
/* 158 */           ((ModelRenderer)this.field_78805_m.get(i)).func_78785_a(scale);
/*     */         } 
/* 160 */       GlStateManager.func_179121_F();
/*     */       
/* 162 */       this.prevRotationMatrix = this.rotationMatrix;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_78794_c(float scale) {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_78791_b(float scale) {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDefaultRotationPoint(float x, float y, float z) {
/* 180 */     this.defaultRotationPointX = x;
/* 181 */     this.defaultRotationPointY = y;
/* 182 */     this.defaultRotationPointZ = z;
/* 183 */     func_78793_a(x, y, z);
/*     */   }
/*     */   
/*     */   public float getDefaultRotationPointX() {
/* 187 */     return this.defaultRotationPointX;
/*     */   }
/*     */   
/*     */   public float getDefaultRotationPointY() {
/* 191 */     return this.defaultRotationPointY;
/*     */   }
/*     */   
/*     */   public float getDefaultRotationPointZ() {
/* 195 */     return this.defaultRotationPointZ;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_78793_a(float x, float y, float z) {
/* 201 */     this.field_78800_c = x;
/* 202 */     this.field_78797_d = y;
/* 203 */     this.field_78798_e = z;
/*     */   }
/*     */ 
/*     */   
/*     */   public void resetRotationPoint() {
/* 208 */     this.field_78800_c = this.defaultRotationPointX;
/* 209 */     this.field_78797_d = this.defaultRotationPointY;
/* 210 */     this.field_78798_e = this.defaultRotationPointZ;
/*     */   }
/*     */   
/*     */   public Vector3f getPositionAsVector() {
/* 214 */     return new Vector3f(this.field_78800_c, this.field_78797_d, this.field_78798_e);
/*     */   }
/*     */   
/*     */   public void setDefaultOffset(float x, float y, float z) {
/* 218 */     this.defaultOffsetX = x;
/* 219 */     this.defaultOffsetY = y;
/* 220 */     this.defaultOffsetZ = z;
/* 221 */     setOffset(x, y, z);
/*     */   }
/*     */   
/*     */   public void setOffset(float x, float y, float z) {
/* 225 */     this.field_82906_o = x;
/* 226 */     this.field_82908_p = y;
/* 227 */     this.field_82907_q = z;
/*     */   }
/*     */   
/*     */   public void resetOffset() {
/* 231 */     this.field_82906_o = this.defaultOffsetX;
/* 232 */     this.field_82908_p = this.defaultOffsetY;
/* 233 */     this.field_82907_q = this.defaultOffsetZ;
/*     */   }
/*     */   
/*     */   public Vector3f getOffsetAsVector() {
/* 237 */     return new Vector3f(this.field_82906_o, this.field_82908_p, this.field_82907_q);
/*     */   }
/*     */   
/*     */   public void setDefaultStretch(float x, float y, float z) {
/* 241 */     this.defaultStretch = new Vector3f(x, y, z);
/* 242 */     setStretch(x, y, z);
/*     */   }
/*     */   
/*     */   public void setStretch(float x, float y, float z) {
/* 246 */     this.stretch = new Vector3f(x, y, z);
/*     */   }
/*     */   
/*     */   public void resetStretch() {
/* 250 */     this.stretch = this.defaultStretch;
/*     */   }
/*     */   
/*     */   public Vector3f getStretchAsVector() {
/* 254 */     return new Vector3f(this.stretch);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setInitialRotationMatrix(Matrix4f matrix) {
/* 262 */     this.defaultRotationMatrix = matrix;
/* 263 */     setRotationMatrix(matrix);
/* 264 */     Matrix4f mat = (Matrix4f)this.rotationMatrix.clone();
/* 265 */     mat.transpose();
/* 266 */     if (this.defaultRotationAsQuaternion == null)
/* 267 */       this.defaultRotationAsQuaternion = new Quat4f(); 
/* 268 */     this.defaultRotationAsQuaternion.set(mat);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setInitialRotationMatrix(float x, float y, float z) {
/* 276 */     Matrix4f mat = new Matrix4f();
/* 277 */     mat.set(MathHelper.quatFromEuler(x, y, z));
/* 278 */     mat.transpose();
/* 279 */     setInitialRotationMatrix(mat);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setRotationMatrix(Matrix4f matrix) {
/* 284 */     this.rotationMatrix.m00 = matrix.m00;
/* 285 */     this.rotationMatrix.m01 = matrix.m01;
/* 286 */     this.rotationMatrix.m02 = matrix.m02;
/* 287 */     this.rotationMatrix.m03 = matrix.m03;
/* 288 */     this.rotationMatrix.m10 = matrix.m10;
/* 289 */     this.rotationMatrix.m11 = matrix.m11;
/* 290 */     this.rotationMatrix.m12 = matrix.m12;
/* 291 */     this.rotationMatrix.m13 = matrix.m13;
/* 292 */     this.rotationMatrix.m20 = matrix.m20;
/* 293 */     this.rotationMatrix.m21 = matrix.m21;
/* 294 */     this.rotationMatrix.m22 = matrix.m22;
/* 295 */     this.rotationMatrix.m23 = matrix.m23;
/* 296 */     this.rotationMatrix.m30 = matrix.m30;
/* 297 */     this.rotationMatrix.m31 = matrix.m31;
/* 298 */     this.rotationMatrix.m32 = matrix.m32;
/* 299 */     this.rotationMatrix.m33 = matrix.m33;
/*     */   }
/*     */ 
/*     */   
/*     */   public void resetRotationMatrix() {
/* 304 */     setRotationMatrix(this.defaultRotationMatrix);
/*     */   }
/*     */   
/*     */   public Matrix4f getRotationMatrix() {
/* 308 */     return this.rotationMatrix;
/*     */   }
/*     */   
/*     */   public Quat4f getDefaultRotationAsQuaternion() {
/* 312 */     return new Quat4f(this.defaultRotationAsQuaternion);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_78788_d(float scale) {
/* 319 */     this.displayList = GLAllocation.func_74526_a(1);
/* 320 */     GlStateManager.func_187423_f(this.displayList, 4864);
/* 321 */     BufferBuilder vertexbuffer = Tessellator.func_178181_a().func_178180_c();
/*     */     
/* 323 */     for (int i = 0; i < this.cubeCSList.size(); i++) {
/* 324 */       ((CSModelBox)this.cubeCSList.get(i)).render(vertexbuffer, scale);
/*     */     }
/* 326 */     GlStateManager.func_187415_K();
/* 327 */     this.compiled = true;
/*     */   }
/*     */ 
/*     */   
/*     */   public List<CSModelBox> getCubeCSList() {
/* 332 */     return this.cubeCSList;
/*     */   }
/*     */ }


/* Location:              C:\Users\Josep\Downloads\tektopia-1.1.0-deobf.jar!\META-INF\libraries\CraftStudio-1.0.0.93-mc1.12-alpha.jar!\com\leviathanstudio\craftstudio\client\model\CSModelRenderer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */