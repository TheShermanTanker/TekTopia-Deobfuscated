/*     */ package com.leviathanstudio.craftstudio.client.model;
/*     */ 
/*     */ import com.leviathanstudio.craftstudio.client.animation.ClientAnimationHandler;
/*     */ import com.leviathanstudio.craftstudio.client.exception.CSResourceNotRegisteredException;
/*     */ import com.leviathanstudio.craftstudio.client.json.CSReadedModel;
/*     */ import com.leviathanstudio.craftstudio.client.json.CSReadedModelBlock;
/*     */ import com.leviathanstudio.craftstudio.client.registry.RegistryHandler;
/*     */ import com.leviathanstudio.craftstudio.common.animation.IAnimated;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import net.minecraft.client.model.ModelBase;
/*     */ import net.minecraft.client.model.ModelRenderer;
/*     */ import net.minecraft.client.model.PositionTextureVertex;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.tileentity.TileEntity;
/*     */ import net.minecraft.util.ResourceLocation;
/*     */ import net.minecraftforge.fml.relauncher.Side;
/*     */ import net.minecraftforge.fml.relauncher.SideOnly;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @SideOnly(Side.CLIENT)
/*     */ public class ModelCraftStudio
/*     */   extends ModelBase
/*     */ {
/*  33 */   private List<CSModelRenderer> parentBlocks = new ArrayList<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ModelCraftStudio(String modid, String modelNameIn, int textureSize) {
/*  46 */     this(modid, modelNameIn, textureSize, textureSize);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ModelCraftStudio(String modid, String modelNameIn, int textureWidth, int textureHeight) {
/*  62 */     this(new ResourceLocation(modid, modelNameIn), textureWidth, textureHeight);
/*     */   }
/*     */ 
/*     */   
/*     */   private ModelCraftStudio(ResourceLocation modelIn, int textureWidth, int textureHeight) {
/*  67 */     this.field_78090_t = textureWidth;
/*  68 */     this.field_78089_u = textureHeight;
/*     */     
/*  70 */     CSReadedModel rModel = (CSReadedModel)RegistryHandler.modelRegistry.func_82594_a(modelIn);
/*  71 */     if (rModel == null) {
/*  72 */       throw new CSResourceNotRegisteredException(modelIn.toString());
/*     */     }
/*     */     
/*  75 */     for (CSReadedModelBlock rBlock : rModel.getParents()) {
/*  76 */       CSModelRenderer modelRend = generateCSModelRend(rBlock);
/*  77 */       this.parentBlocks.add(modelRend);
/*  78 */       generateChild(rBlock, modelRend);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void generateChild(CSReadedModelBlock rParent, CSModelRenderer parent) {
/*  85 */     for (CSReadedModelBlock rBlock : rParent.getChilds()) {
/*  86 */       CSModelRenderer modelRend = generateCSModelRend(rBlock);
/*  87 */       parent.func_78792_a(modelRend);
/*  88 */       generateChild(rBlock, modelRend);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private CSModelRenderer generateCSModelRend(CSReadedModelBlock rBlock) {
/*  94 */     CSModelRenderer modelRend = new CSModelRenderer(this, rBlock.getName(), rBlock.getTexOffset()[0], rBlock.getTexOffset()[1]);
/*  95 */     if (rBlock.getVertex() != null) {
/*  96 */       PositionTextureVertex[] vertices = new PositionTextureVertex[8];
/*  97 */       for (int i = 0; i < 8; i++)
/*  98 */         vertices[i] = new PositionTextureVertex(rBlock.getVertex()[i][0], rBlock.getVertex()[i][1], rBlock.getVertex()[i][2], 0.0F, 0.0F); 
/*  99 */       modelRend.addBox(vertices, CSModelBox.getTextureUVsForRect(rBlock.getTexOffset()[0], rBlock.getTexOffset()[1], (rBlock.getSize()).x, 
/* 100 */             (rBlock.getSize()).y, (rBlock.getSize()).z));
/*     */     } else {
/*     */       
/* 103 */       modelRend.addBox(-(rBlock.getSize()).x / 2.0F, -(rBlock.getSize()).y / 2.0F, -(rBlock.getSize()).z / 2.0F, (rBlock.getSize()).x, (rBlock.getSize()).y, 
/* 104 */           (rBlock.getSize()).z);
/* 105 */     }  modelRend.setDefaultRotationPoint((rBlock.getRotationPoint()).x, (rBlock.getRotationPoint()).y, (rBlock.getRotationPoint()).z);
/* 106 */     modelRend.setInitialRotationMatrix((rBlock.getRotation()).x, (rBlock.getRotation()).y, (rBlock.getRotation()).z);
/* 107 */     modelRend.setDefaultOffset((rBlock.getOffset()).x, (rBlock.getOffset()).y, (rBlock.getOffset()).z);
/* 108 */     modelRend.setDefaultStretch((rBlock.getStretch()).x, (rBlock.getStretch()).y, (rBlock.getStretch()).z);
/* 109 */     modelRend.func_78787_b(this.field_78090_t, this.field_78089_u);
/* 110 */     return modelRend;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void render(TileEntity tileEntityIn) {
/* 123 */     float modelScale = 0.0625F;
/* 124 */     ClientAnimationHandler.performAnimationInModel(this.parentBlocks, (IAnimated)tileEntityIn);
/* 125 */     for (int i = 0; i < this.parentBlocks.size(); i++) {
/* 126 */       ((CSModelRenderer)this.parentBlocks.get(i)).func_78785_a(modelScale);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void render() {
/* 136 */     float modelScale = 0.0625F;
/* 137 */     for (int i = 0; i < this.parentBlocks.size(); i++) {
/* 138 */       ((CSModelRenderer)this.parentBlocks.get(i)).func_78785_a(modelScale);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void func_78088_a(Entity entityIn, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch, float scale) {
/* 144 */     super.func_78088_a(entityIn, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch, scale);
/* 145 */     ClientAnimationHandler.performAnimationInModel(this.parentBlocks, (IAnimated)entityIn);
/* 146 */     for (int i = 0; i < this.parentBlocks.size(); i++) {
/* 147 */       ((CSModelRenderer)this.parentBlocks.get(i)).func_78785_a(scale);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static CSModelRenderer getModelRendererFromNameAndBlock(String name, CSModelRenderer block) {
/* 154 */     if (block.field_78802_n.equals(name)) {
/* 155 */       return block;
/*     */     }
/* 157 */     for (ModelRenderer child : block.field_78805_m) {
/* 158 */       if (child instanceof CSModelRenderer) {
/* 159 */         CSModelRenderer childModel = (CSModelRenderer)child;
/* 160 */         CSModelRenderer result = getModelRendererFromNameAndBlock(name, childModel);
/* 161 */         if (result != null)
/* 162 */           return result; 
/*     */       } 
/*     */     } 
/* 165 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public CSModelRenderer getModelRendererFromName(String name) {
/* 171 */     for (CSModelRenderer parent : this.parentBlocks) {
/* 172 */       CSModelRenderer result = getModelRendererFromNameAndBlock(name, parent);
/* 173 */       if (result != null)
/* 174 */         return result; 
/*     */     } 
/* 176 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public List<CSModelRenderer> getParentBlocks() {
/* 181 */     return this.parentBlocks;
/*     */   }
/*     */ }


/* Location:              C:\Users\Josep\Downloads\tektopia-1.1.0-deobf.jar!\META-INF\libraries\CraftStudio-1.0.0.93-mc1.12-alpha.jar!\com\leviathanstudio\craftstudio\client\model\ModelCraftStudio.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */