/*    */ package com.leviathanstudio.craftstudio.proxy;
/*    */ 
/*    */ import com.leviathanstudio.craftstudio.CraftStudioApi;
/*    */ import com.leviathanstudio.craftstudio.client.animation.ClientAnimationHandler;
/*    */ import com.leviathanstudio.craftstudio.client.registry.CSRegistryHelper;
/*    */ import com.leviathanstudio.craftstudio.client.registry.RegistryHandler;
/*    */ import com.leviathanstudio.craftstudio.common.animation.AnimationHandler;
/*    */ import java.lang.reflect.Method;
/*    */ import java.util.Set;
/*    */ import net.minecraftforge.fml.common.discovery.ASMDataTable;
/*    */ import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CSClientProxy
/*    */   extends CSCommonProxy
/*    */ {
/*    */   public void preInit(FMLPreInitializationEvent e) {
/* 30 */     super.preInit(e);
/* 31 */     loadCraftStudioLoaders(e);
/*    */   }
/*    */ 
/*    */   
/*    */   public <T extends com.leviathanstudio.craftstudio.common.animation.IAnimated> AnimationHandler<T> getNewAnimationHandler(Class<T> animatedClass) {
/* 36 */     return (AnimationHandler<T>)new ClientAnimationHandler();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private void loadCraftStudioLoaders(FMLPreInitializationEvent e) {
/* 43 */     RegistryHandler.init();
/*    */     
/* 45 */     ASMDataTable dataTable = e.getAsmData();
/* 46 */     Set<ASMDataTable.ASMData> datas = dataTable.getAll("com.leviathanstudio.craftstudio.client.registry.CraftStudioLoader");
/* 47 */     for (ASMDataTable.ASMData data : datas) {
/* 48 */       String className = data.getClassName();
/* 49 */       String methodName = data.getObjectName().substring(0, data.getObjectName().indexOf("("));
/*    */       try {
/* 51 */         Method method = Class.forName(className).getMethod(methodName, new Class[0]);
/* 52 */         method.invoke(null, new Object[0]);
/* 53 */       } catch (NoSuchMethodException|SecurityException|ClassNotFoundException e1) {
/* 54 */         e1.printStackTrace();
/* 55 */         CraftStudioApi.getLogger().error("Error loading @CraftStudioLoader in class " + className + " for method " + methodName + "().");
/* 56 */         CraftStudioApi.getLogger().error("Does that method has arguments ? Because it should have none.");
/* 57 */       } catch (IllegalAccessException|IllegalArgumentException|java.lang.reflect.InvocationTargetException|NullPointerException e1) {
/* 58 */         e1.printStackTrace();
/* 59 */         CraftStudioApi.getLogger().error("Error loading craftstudio assets in class " + className + " for method " + methodName + "().");
/* 60 */         CraftStudioApi.getLogger().error("Is that method 'static' ? Because it should.");
/*    */       } 
/*    */     } 
/*    */     
/* 64 */     CSRegistryHelper.loadModels();
/* 65 */     CSRegistryHelper.loadAnims();
/*    */   }
/*    */ }


/* Location:              C:\Users\Josep\Downloads\tektopia-1.1.0-deobf.jar!\META-INF\libraries\CraftStudio-1.0.0.93-mc1.12-alpha.jar!\com\leviathanstudio\craftstudio\proxy\CSClientProxy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */