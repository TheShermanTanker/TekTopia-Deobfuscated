/*    */ package com.leviathanstudio.craftstudio.proxy;
/*    */ 
/*    */ import com.leviathanstudio.craftstudio.CraftStudioApi;
/*    */ import com.leviathanstudio.craftstudio.common.animation.AnimationHandler;
/*    */ import com.leviathanstudio.craftstudio.common.network.ClientIAnimatedEventMessage;
/*    */ import com.leviathanstudio.craftstudio.common.network.ServerIAnimatedEventMessage;
/*    */ import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
/*    */ import net.minecraftforge.fml.relauncher.Side;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class CSCommonProxy
/*    */ {
/*    */   public void preInit(FMLPreInitializationEvent e) {
/* 25 */     CraftStudioApi.NETWORK.registerMessage(ClientIAnimatedEventMessage.ClientIAnimatedEventHandler.class, ClientIAnimatedEventMessage.class, 0, Side.CLIENT);
/* 26 */     CraftStudioApi.NETWORK.registerMessage(ServerIAnimatedEventMessage.ServerIAnimatedEventHandler.class, ServerIAnimatedEventMessage.class, 1, Side.SERVER);
/*    */   }
/*    */   
/*    */   public abstract <T extends com.leviathanstudio.craftstudio.common.animation.IAnimated> AnimationHandler<T> getNewAnimationHandler(Class<T> paramClass);
/*    */ }


/* Location:              C:\Users\Josep\Downloads\tektopia-1.1.0-deobf.jar!\META-INF\libraries\CraftStudio-1.0.0.93-mc1.12-alpha.jar!\com\leviathanstudio\craftstudio\proxy\CSCommonProxy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */