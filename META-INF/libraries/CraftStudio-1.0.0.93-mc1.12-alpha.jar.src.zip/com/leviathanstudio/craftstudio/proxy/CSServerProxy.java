/*    */ package com.leviathanstudio.craftstudio.proxy;
/*    */ 
/*    */ import com.leviathanstudio.craftstudio.common.animation.AnimationHandler;
/*    */ import com.leviathanstudio.craftstudio.server.animation.ServerAnimationHandler;
/*    */ import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CSServerProxy
/*    */   extends CSCommonProxy
/*    */ {
/*    */   public void preInit(FMLPreInitializationEvent e) {
/* 21 */     super.preInit(e);
/*    */   }
/*    */ 
/*    */   
/*    */   public <T extends com.leviathanstudio.craftstudio.common.animation.IAnimated> AnimationHandler<T> getNewAnimationHandler(Class<T> animatedClass) {
/* 26 */     return (AnimationHandler<T>)new ServerAnimationHandler();
/*    */   }
/*    */ }


/* Location:              C:\Users\Josep\Downloads\tektopia-1.1.0-deobf.jar!\META-INF\libraries\CraftStudio-1.0.0.93-mc1.12-alpha.jar!\com\leviathanstudio\craftstudio\proxy\CSServerProxy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */