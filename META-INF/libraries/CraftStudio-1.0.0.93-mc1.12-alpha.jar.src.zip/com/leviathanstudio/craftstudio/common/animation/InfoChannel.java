/*    */ package com.leviathanstudio.craftstudio.common.animation;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class InfoChannel
/*    */   extends Channel
/*    */ {
/*    */   public InfoChannel(String channelName) {
/* 14 */     super(channelName);
/* 15 */     this.totalFrames = 0;
/*    */   }
/*    */   
/*    */   public InfoChannel(String channelName, float fps, boolean looped) {
/* 19 */     super(channelName, fps, looped);
/*    */   }
/*    */ }


/* Location:              C:\Users\Josep\Downloads\tektopia-1.1.0-deobf.jar!\META-INF\libraries\CraftStudio-1.0.0.93-mc1.12-alpha.jar!\com\leviathanstudio\craftstudio\common\animation\InfoChannel.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */