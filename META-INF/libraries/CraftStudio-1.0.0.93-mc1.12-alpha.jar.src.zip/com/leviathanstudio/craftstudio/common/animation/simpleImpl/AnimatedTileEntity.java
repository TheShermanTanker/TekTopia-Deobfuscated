/*     */ package com.leviathanstudio.craftstudio.common.animation.simpleImpl;
/*     */ 
/*     */ import com.leviathanstudio.craftstudio.CraftStudioApi;
/*     */ import com.leviathanstudio.craftstudio.common.animation.AnimationHandler;
/*     */ import com.leviathanstudio.craftstudio.common.animation.IAnimated;
/*     */ import net.minecraft.tileentity.TileEntity;
/*     */ import net.minecraft.util.ITickable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AnimatedTileEntity
/*     */   extends TileEntity
/*     */   implements IAnimated, ITickable
/*     */ {
/*  25 */   protected static AnimationHandler animHandler = CraftStudioApi.getNewAnimationHandler(AnimatedTileEntity.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_73660_a() {
/*  41 */     getAnimationHandler().animationsUpdate(this);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public <T extends IAnimated> AnimationHandler<T> getAnimationHandler() {
/*  47 */     return animHandler;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getDimension() {
/*  52 */     return this.field_145850_b.field_73011_w.getDimension();
/*     */   }
/*     */ 
/*     */   
/*     */   public double getX() {
/*  57 */     return this.field_174879_c.func_177958_n();
/*     */   }
/*     */ 
/*     */   
/*     */   public double getY() {
/*  62 */     return this.field_174879_c.func_177956_o();
/*     */   }
/*     */ 
/*     */   
/*     */   public double getZ() {
/*  67 */     return this.field_174879_c.func_177952_p();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isWorldRemote() {
/*  72 */     return this.field_145850_b.field_72995_K;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/*  78 */     int prime = 31;
/*  79 */     int result = 1;
/*  80 */     result = 31 * result + this.field_174879_c.func_177958_n();
/*  81 */     result = 31 * result + this.field_174879_c.func_177956_o();
/*  82 */     result = 31 * result + this.field_174879_c.func_177952_p();
/*  83 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/*  89 */     if (this == obj)
/*  90 */       return true; 
/*  91 */     if (obj == null)
/*  92 */       return false; 
/*  93 */     if (getClass() != obj.getClass())
/*  94 */       return false; 
/*  95 */     AnimatedTileEntity other = (AnimatedTileEntity)obj;
/*  96 */     if (this.field_174879_c.func_177958_n() != other.field_174879_c.func_177958_n())
/*  97 */       return false; 
/*  98 */     if (this.field_174879_c.func_177956_o() != other.field_174879_c.func_177956_o())
/*  99 */       return false; 
/* 100 */     if (this.field_174879_c.func_177952_p() != other.field_174879_c.func_177952_p())
/* 101 */       return false; 
/* 102 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Users\Josep\Downloads\tektopia-1.1.0-deobf.jar!\META-INF\libraries\CraftStudio-1.0.0.93-mc1.12-alpha.jar!\com\leviathanstudio\craftstudio\common\animation\simpleImpl\AnimatedTileEntity.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */