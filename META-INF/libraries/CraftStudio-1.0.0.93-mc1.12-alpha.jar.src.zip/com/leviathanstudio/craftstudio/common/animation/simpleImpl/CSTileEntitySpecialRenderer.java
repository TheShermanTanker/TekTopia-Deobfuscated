/*    */ package com.leviathanstudio.craftstudio.common.animation.simpleImpl;
/*    */ 
/*    */ import com.leviathanstudio.craftstudio.client.model.ModelCraftStudio;
/*    */ import com.leviathanstudio.craftstudio.client.util.MathHelper;
/*    */ import java.nio.FloatBuffer;
/*    */ import javax.vecmath.Matrix4f;
/*    */ import net.minecraft.client.renderer.GlStateManager;
/*    */ import net.minecraft.client.renderer.tileentity.TileEntitySpecialRenderer;
/*    */ import net.minecraft.tileentity.TileEntity;
/*    */ import net.minecraft.util.ResourceLocation;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CSTileEntitySpecialRenderer<T extends TileEntity>
/*    */   extends TileEntitySpecialRenderer<T>
/*    */ {
/*    */   public static final FloatBuffer ROTATION_CORRECTOR;
/*    */   protected ModelCraftStudio model;
/*    */   protected ResourceLocation texture;
/*    */   
/*    */   static {
/* 31 */     Matrix4f mat = new Matrix4f();
/* 32 */     mat.set(MathHelper.quatFromEuler(180.0F, 0.0F, 0.0F));
/* 33 */     ROTATION_CORRECTOR = MathHelper.makeFloatBuffer(mat);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public CSTileEntitySpecialRenderer(String modid, String modelNameIn, int textureWidth, int textureHeigth, ResourceLocation texture) {
/* 43 */     this.model = new ModelCraftStudio(modid, modelNameIn, textureWidth, textureHeigth);
/* 44 */     this.texture = texture;
/*    */   }
/*    */ 
/*    */   
/*    */   public void func_192841_a(T te, double x, double y, double z, float partialTicks, int destroyStage, float alpha) {
/* 49 */     GlStateManager.func_179094_E();
/*    */     
/* 51 */     GlStateManager.func_179137_b(x + 0.5D, y + 1.5D, z + 0.5D);
/*    */     
/* 53 */     GlStateManager.func_179110_a(ROTATION_CORRECTOR);
/* 54 */     func_147499_a(this.texture);
/* 55 */     this.model.render((TileEntity)te);
/* 56 */     GlStateManager.func_179121_F();
/*    */   }
/*    */ }


/* Location:              C:\Users\Josep\Downloads\tektopia-1.1.0-deobf.jar!\META-INF\libraries\CraftStudio-1.0.0.93-mc1.12-alpha.jar!\com\leviathanstudio\craftstudio\common\animation\simpleImpl\CSTileEntitySpecialRenderer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */