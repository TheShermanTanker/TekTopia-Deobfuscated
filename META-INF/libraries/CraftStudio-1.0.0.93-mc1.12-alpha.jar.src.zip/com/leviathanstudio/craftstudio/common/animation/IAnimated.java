package com.leviathanstudio.craftstudio.common.animation;

public interface IAnimated {
  <T extends IAnimated> AnimationHandler<T> getAnimationHandler();
  
  int getDimension();
  
  double getX();
  
  double getY();
  
  double getZ();
  
  boolean isWorldRemote();
}


/* Location:              C:\Users\Josep\Downloads\tektopia-1.1.0-deobf.jar!\META-INF\libraries\CraftStudio-1.0.0.93-mc1.12-alpha.jar!\com\leviathanstudio\craftstudio\common\animation\IAnimated.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */