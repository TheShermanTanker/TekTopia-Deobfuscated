/*    */ package com.leviathanstudio.craftstudio.common.animation.simpleImpl;
/*    */ 
/*    */ import com.leviathanstudio.craftstudio.CraftStudioApi;
/*    */ import com.leviathanstudio.craftstudio.common.animation.AnimationHandler;
/*    */ import com.leviathanstudio.craftstudio.common.animation.IAnimated;
/*    */ import net.minecraft.entity.EntityCreature;
/*    */ import net.minecraft.world.World;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AnimatedEntity
/*    */   extends EntityCreature
/*    */   implements IAnimated
/*    */ {
/* 24 */   protected static AnimationHandler animHandler = CraftStudioApi.getNewAnimationHandler(AnimatedEntity.class);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public AnimatedEntity(World worldIn) {
/* 33 */     super(worldIn);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void func_70636_d() {
/* 40 */     super.func_70636_d();
/* 41 */     getAnimationHandler().animationsUpdate(this);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public <T extends IAnimated> AnimationHandler<T> getAnimationHandler() {
/* 47 */     return animHandler;
/*    */   }
/*    */ 
/*    */   
/*    */   public int getDimension() {
/* 52 */     return this.field_71093_bK;
/*    */   }
/*    */ 
/*    */   
/*    */   public double getX() {
/* 57 */     return this.field_70165_t;
/*    */   }
/*    */ 
/*    */   
/*    */   public double getY() {
/* 62 */     return this.field_70163_u;
/*    */   }
/*    */ 
/*    */   
/*    */   public double getZ() {
/* 67 */     return this.field_70161_v;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isWorldRemote() {
/* 72 */     return this.field_70170_p.field_72995_K;
/*    */   }
/*    */ }


/* Location:              C:\Users\Josep\Downloads\tektopia-1.1.0-deobf.jar!\META-INF\libraries\CraftStudio-1.0.0.93-mc1.12-alpha.jar!\com\leviathanstudio\craftstudio\common\animation\simpleImpl\AnimatedEntity.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */