/*    */ package com.leviathanstudio.craftstudio.common.animation;
/*    */ 
/*    */ import com.leviathanstudio.craftstudio.client.model.CSModelRenderer;
/*    */ import net.minecraftforge.fml.relauncher.Side;
/*    */ import net.minecraftforge.fml.relauncher.SideOnly;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class CustomChannel
/*    */   extends InfoChannel
/*    */ {
/*    */   public CustomChannel(String channelName) {
/* 19 */     super(channelName);
/*    */   }
/*    */   
/*    */   @SideOnly(Side.CLIENT)
/*    */   public abstract void update(CSModelRenderer paramCSModelRenderer, IAnimated paramIAnimated);
/*    */ }


/* Location:              C:\Users\Josep\Downloads\tektopia-1.1.0-deobf.jar!\META-INF\libraries\CraftStudio-1.0.0.93-mc1.12-alpha.jar!\com\leviathanstudio\craftstudio\common\animation\CustomChannel.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */