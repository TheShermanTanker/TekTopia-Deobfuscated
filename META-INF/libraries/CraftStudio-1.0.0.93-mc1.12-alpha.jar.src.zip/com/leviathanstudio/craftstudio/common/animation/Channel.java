/*    */ package com.leviathanstudio.craftstudio.common.animation;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Channel
/*    */ {
/*    */   public String name;
/*    */   public float fps;
/* 18 */   public int totalFrames = -1;
/*    */   
/*    */   public boolean looped = false;
/*    */   
/*    */   public Channel(String channelName) {
/* 23 */     this.name = channelName;
/*    */   }
/*    */   
/*    */   public Channel(String channelName, float fps, boolean looped) {
/* 27 */     this(channelName);
/* 28 */     this.fps = fps;
/* 29 */     this.looped = looped;
/*    */   }
/*    */ }


/* Location:              C:\Users\Josep\Downloads\tektopia-1.1.0-deobf.jar!\META-INF\libraries\CraftStudio-1.0.0.93-mc1.12-alpha.jar!\com\leviathanstudio\craftstudio\common\animation\Channel.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */