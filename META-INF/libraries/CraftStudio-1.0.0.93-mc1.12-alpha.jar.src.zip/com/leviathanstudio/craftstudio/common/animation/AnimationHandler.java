/*     */ package com.leviathanstudio.craftstudio.common.animation;
/*     */ 
/*     */ import com.leviathanstudio.craftstudio.common.network.CSNetworkHelper;
/*     */ import com.leviathanstudio.craftstudio.common.network.EnumIAnimatedEvent;
/*     */ import com.leviathanstudio.craftstudio.common.network.IAnimatedEventMessage;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import net.minecraft.util.ResourceLocation;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AnimationHandler<T extends IAnimated>
/*     */ {
/*  27 */   protected List<String> channelIds = new ArrayList<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addAnim(String modid, String animNameIn, String modelNameIn, boolean looped) {
/*  42 */     ResourceLocation anim = new ResourceLocation(modid, animNameIn);
/*  43 */     this.channelIds.add(anim.toString());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addAnim(String modid, String animNameIn, CustomChannel customChannelIn) {
/*  59 */     ResourceLocation anim = new ResourceLocation(modid, animNameIn);
/*  60 */     this.channelIds.add(anim.toString());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addAnim(String modid, String invertedAnimationName, String animationToInvert) {
/*  74 */     ResourceLocation anim = new ResourceLocation(modid, invertedAnimationName);
/*  75 */     this.channelIds.add(anim.toString());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void startAnimation(String res, float startingFrame, T animatedElement) {
/*  89 */     if (animatedElement.isWorldRemote()) {
/*  90 */       clientStartAnimation(res, startingFrame, animatedElement);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void networkStartAnimation(String res, float startingFrame, T animatedElement, boolean clientSend) {
/* 110 */     if (animatedElement.isWorldRemote() == clientSend) {
/* 111 */       serverInitAnimation(res, startingFrame, animatedElement);
/* 112 */       CSNetworkHelper.sendIAnimatedEvent(new IAnimatedEventMessage(EnumIAnimatedEvent.START_ANIM, (IAnimated)animatedElement, 
/* 113 */             getAnimIdFromName(res), startingFrame));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract boolean clientStartAnimation(String paramString, float paramFloat, T paramT);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract boolean serverInitAnimation(String paramString, float paramFloat, T paramT);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract boolean serverStartAnimation(String paramString, float paramFloat, T paramT);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void stopAnimation(String res, T animatedElement) {
/* 158 */     if (animatedElement.isWorldRemote()) {
/* 159 */       clientStopAnimation(res, animatedElement);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void networkStopAnimation(String res, T animatedElement, boolean clientSend) {
/* 174 */     if (animatedElement.isWorldRemote() == clientSend) {
/* 175 */       serverStopAnimation(res, animatedElement);
/* 176 */       CSNetworkHelper.sendIAnimatedEvent(new IAnimatedEventMessage(EnumIAnimatedEvent.STOP_ANIM, (IAnimated)animatedElement, getAnimIdFromName(res)));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract boolean clientStopAnimation(String paramString, T paramT);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract boolean serverStopAnimation(String paramString, T paramT);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void stopStartAnimation(String animToStop, String animToStart, float startingFrame, T animatedElement) {
/* 203 */     if (animatedElement.isWorldRemote()) {
/* 204 */       clientStopStartAnimation(animToStop, animToStart, startingFrame, animatedElement);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void networkStopStartAnimation(String animToStop, String animToStart, float startingFrame, T animatedElement, boolean clientSend) {
/* 223 */     if (animatedElement.isWorldRemote() == clientSend) {
/* 224 */       serverStopStartAnimation(animToStop, animToStart, startingFrame, animatedElement);
/* 225 */       CSNetworkHelper.sendIAnimatedEvent(new IAnimatedEventMessage(EnumIAnimatedEvent.STOP_START_ANIM, (IAnimated)animatedElement, 
/* 226 */             getAnimIdFromName(animToStart), startingFrame, getAnimIdFromName(animToStop)));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean clientStopStartAnimation(String animToStop, String animToStart, float startingFrame, T animatedElement) {
/* 246 */     boolean stopSucces = clientStopAnimation(animToStop, animatedElement);
/* 247 */     return (clientStartAnimation(animToStart, startingFrame, animatedElement) && stopSucces);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean serverStopStartAnimation(String animToStop, String animToStart, float startingFrame, T animatedElement) {
/* 265 */     boolean stopSucces = serverStopAnimation(animToStop, animatedElement);
/* 266 */     return (serverInitAnimation(animToStart, startingFrame, animatedElement) && stopSucces);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract void animationsUpdate(T paramT);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract boolean isAnimationActive(String paramString, T paramT);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract boolean isHoldAnimationActive(String paramString, T paramT);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract boolean canUpdateAnimation(Channel paramChannel, T paramT);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getAnimNameFromId(short id) {
/* 320 */     return this.channelIds.get(id);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public short getAnimIdFromName(String name) {
/* 331 */     return (short)this.channelIds.indexOf(name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean onClientIAnimatedEvent(IAnimatedEventMessage message) {
/* 343 */     AnimationHandler<IAnimated> hand = message.animated.getAnimationHandler();
/* 344 */     switch (EnumIAnimatedEvent.getEvent(message.event)) {
/*     */       case START_ANIM:
/* 346 */         return hand.clientStartAnimation(hand.getAnimNameFromId(message.animId), message.keyframeInfo, message.animated);
/*     */       case STOP_ANIM:
/* 348 */         return hand.clientStopAnimation(hand.getAnimNameFromId(message.animId), message.animated);
/*     */       case STOP_START_ANIM:
/* 350 */         return hand.clientStopStartAnimation(hand.getAnimNameFromId(message.optAnimId), hand.getAnimNameFromId(message.animId), message.keyframeInfo, message.animated);
/*     */     } 
/*     */     
/* 353 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean onServerIAnimatedEvent(IAnimatedEventMessage message) {
/* 366 */     AnimationHandler<IAnimated> hand = message.animated.getAnimationHandler();
/* 367 */     switch (EnumIAnimatedEvent.getEvent(message.event)) {
/*     */       case START_ANIM:
/* 369 */         return hand.serverInitAnimation(hand.getAnimNameFromId(message.animId), message.keyframeInfo, message.animated);
/*     */       case ANSWER_START_ANIM:
/* 371 */         return hand.serverStartAnimation(hand.getAnimNameFromId(message.animId), message.keyframeInfo, message.animated);
/*     */       case STOP_ANIM:
/* 373 */         hand.serverStopAnimation(hand.getAnimNameFromId(message.animId), message.animated);
/* 374 */         return true;
/*     */       case STOP_START_ANIM:
/* 376 */         hand.serverStopStartAnimation(hand.getAnimNameFromId(message.optAnimId), hand.getAnimNameFromId(message.animId), message.keyframeInfo, message.animated);
/*     */         
/* 378 */         return true;
/*     */     } 
/* 380 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class AnimInfo
/*     */   {
/*     */     public long prevTime;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public float currentFrame;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public AnimInfo(long prevTime, float currentFrame) {
/* 400 */       this.prevTime = prevTime;
/* 401 */       this.currentFrame = currentFrame;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void startAnimation(String modid, String animationName, T animatedElement) {
/* 414 */     startAnimation(modid, animationName, 0.0F, animatedElement);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void startAnimation(String modid, String animationName, float startingFrame, T animatedElement) {
/* 431 */     startAnimation(modid + ":" + animationName, startingFrame, animatedElement);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void networkStartAnimation(String modid, String animationName, T animatedElement) {
/* 440 */     networkStartAnimation(modid, animationName, 0.0F, animatedElement, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void networkStartAnimation(String modid, String animationName, T animatedElement, boolean clientSend) {
/* 449 */     networkStartAnimation(modid, animationName, 0.0F, animatedElement, clientSend);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void networkStartAnimation(String modid, String animationName, float startingFrame, T animatedElement, boolean clientSend) {
/* 472 */     networkStartAnimation(modid + ":" + animationName, startingFrame, animatedElement, clientSend);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void stopAnimation(String modid, String animationName, T animatedElement) {
/* 487 */     stopAnimation(modid + ":" + animationName, animatedElement);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void networkStopAnimation(String modid, String animationName, T animatedElement) {
/* 496 */     networkStopAnimation(modid + ":" + animationName, animatedElement, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void networkStopAnimation(String modid, String animationName, T animatedElement, boolean clientSend) {
/* 513 */     networkStopAnimation(modid + ":" + animationName, animatedElement, clientSend);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void stopStartAnimation(String modid, String animToStop, String animToStart, T animatedElement) {
/* 522 */     stopStartAnimation(modid + ":" + animToStop, modid + ":" + animToStart, 0.0F, animatedElement);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void stopStartAnimation(String modid, String animToStop, String animToStart, float startingFrame, T animatedElement) {
/* 534 */     stopStartAnimation(modid + ":" + animToStop, modid + ":" + animToStart, startingFrame, animatedElement);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void stopStartAnimation(String modid1, String animToStop, String modid2, String animToStart, float startingFrame, T animatedElement) {
/* 557 */     stopStartAnimation(modid1 + ":" + animToStop, modid2 + ":" + animToStart, startingFrame, animatedElement);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void networkStopStartAnimation(String modid, String animToStop, String animToStart, T animatedElement) {
/* 566 */     networkStopStartAnimation(modid + ":" + animToStop, modid + ":" + animToStart, 0.0F, animatedElement, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void networkStopStartAnimation(String modid, String animToStop, String animToStart, T animatedElement, boolean clientSend) {
/* 575 */     networkStopStartAnimation(modid + ":" + animToStop, modid + ":" + animToStart, 0.0F, animatedElement, clientSend);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void networkStopStartAnimation(String modid, String animToStop, String animToStart, float startingFrame, T animatedElement, boolean clientSend) {
/* 588 */     networkStopStartAnimation(modid + ":" + animToStop, modid + ":" + animToStart, startingFrame, animatedElement, clientSend);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void networkStopStartAnimation(String modid1, String animToStop, String modid2, String animToStart, float startingFrame, T animatedElement, boolean clientSend) {
/* 612 */     networkStopStartAnimation(modid1 + ":" + animToStop, modid2 + ":" + animToStart, startingFrame, animatedElement, clientSend);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isAnimationActive(String modid, String animationName, T animatedElement) {
/* 627 */     return isAnimationActive(modid + ":" + animationName, animatedElement);
/*     */   }
/*     */ }


/* Location:              C:\Users\Josep\Downloads\tektopia-1.1.0-deobf.jar!\META-INF\libraries\CraftStudio-1.0.0.93-mc1.12-alpha.jar!\com\leviathanstudio\craftstudio\common\animation\AnimationHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */