/*     */ package com.leviathanstudio.craftstudio.common.network;
/*     */ 
/*     */ import com.leviathanstudio.craftstudio.CraftStudioApi;
/*     */ import com.leviathanstudio.craftstudio.common.animation.IAnimated;
/*     */ import io.netty.buffer.ByteBuf;
/*     */ import java.util.UUID;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.tileentity.TileEntity;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ import net.minecraftforge.fml.common.network.simpleimpl.IMessage;
/*     */ import net.minecraftforge.fml.common.network.simpleimpl.MessageContext;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class IAnimatedEventMessage
/*     */   implements IMessage
/*     */ {
/*     */   public short event;
/*     */   public short animId;
/*  31 */   public short optAnimId = -1;
/*     */   
/*  33 */   public float keyframeInfo = -1.0F;
/*     */   
/*     */   public IAnimated animated;
/*     */   
/*     */   public long most;
/*     */   
/*     */   public long least;
/*     */   public int x;
/*     */   public int y;
/*     */   public int z;
/*     */   public boolean hasEntity;
/*     */   
/*     */   public IAnimatedEventMessage() {}
/*     */   
/*     */   public IAnimatedEventMessage(EnumIAnimatedEvent event, IAnimated animated, short animId) {
/*  48 */     if (event != null)
/*  49 */       this.event = event.getId(); 
/*  50 */     this.animated = animated;
/*  51 */     this.animId = animId;
/*     */   }
/*     */ 
/*     */   
/*     */   public IAnimatedEventMessage(EnumIAnimatedEvent event, IAnimated animated, short animId, float keyframeInfo) {
/*  56 */     this(event, animated, animId);
/*  57 */     this.keyframeInfo = keyframeInfo;
/*     */   }
/*     */ 
/*     */   
/*     */   public IAnimatedEventMessage(EnumIAnimatedEvent event, IAnimated animated, short animId, float keyframeInfo, short optAnimId) {
/*  62 */     this(event, animated, animId, keyframeInfo);
/*  63 */     this.optAnimId = optAnimId;
/*     */   }
/*     */ 
/*     */   
/*     */   public IAnimatedEventMessage(IAnimatedEventMessage eventObj) {
/*  68 */     this(null, eventObj.animated, eventObj.animId, eventObj.keyframeInfo, eventObj.optAnimId);
/*  69 */     this.event = eventObj.event;
/*     */   }
/*     */ 
/*     */   
/*     */   public void fromBytes(ByteBuf buf) {
/*  74 */     short actualEvent = buf.readShort();
/*  75 */     if (actualEvent < 0 || actualEvent >= 8) {
/*  76 */       this.event = -1;
/*  77 */       CraftStudioApi.getLogger().error("Networking error : invalid packet.");
/*     */       return;
/*     */     } 
/*  80 */     if (actualEvent < 4) {
/*  81 */       this.most = buf.readLong();
/*  82 */       this.least = buf.readLong();
/*  83 */       this.event = actualEvent;
/*  84 */       this.hasEntity = true;
/*     */     } else {
/*     */       
/*  87 */       this.x = buf.readInt();
/*  88 */       this.y = buf.readInt();
/*  89 */       this.z = buf.readInt();
/*  90 */       this.event = (short)(actualEvent - 4);
/*  91 */       this.hasEntity = false;
/*     */     } 
/*  93 */     this.animId = buf.readShort();
/*  94 */     if (this.event != 2)
/*  95 */       this.keyframeInfo = buf.readFloat(); 
/*  96 */     if (this.event > 2) {
/*  97 */       this.optAnimId = buf.readShort();
/*     */     }
/*     */   }
/*     */   
/*     */   public void toBytes(ByteBuf buf) {
/* 102 */     if (this.event < 0 || this.event >= 4) {
/* 103 */       buf.writeShort(-1);
/* 104 */       CraftStudioApi.getLogger().error("Unsuported event id " + this.event + " for network message.");
/*     */       return;
/*     */     } 
/* 107 */     if (this.animated instanceof Entity) {
/* 108 */       Entity e = (Entity)this.animated;
/* 109 */       buf.writeShort(this.event);
/* 110 */       UUID uuid = e.func_110124_au();
/* 111 */       buf.writeLong(uuid.getMostSignificantBits());
/* 112 */       buf.writeLong(uuid.getLeastSignificantBits());
/*     */     }
/* 114 */     else if (this.animated instanceof TileEntity) {
/* 115 */       TileEntity te = (TileEntity)this.animated;
/* 116 */       buf.writeShort(this.event + 4);
/* 117 */       BlockPos pos = te.func_174877_v();
/* 118 */       buf.writeInt(pos.func_177958_n());
/* 119 */       buf.writeInt(pos.func_177956_o());
/* 120 */       buf.writeInt(pos.func_177952_p());
/*     */     } else {
/*     */       
/* 123 */       buf.writeShort(-1);
/* 124 */       CraftStudioApi.getLogger().error("Unsuported class " + this.animated.getClass().getSimpleName() + " for network message.");
/* 125 */       CraftStudioApi.getLogger().error("You are trying to animate an other class than Entity or TileEntity.");
/*     */       return;
/*     */     } 
/* 128 */     buf.writeShort(this.animId);
/* 129 */     if (this.event != EnumIAnimatedEvent.STOP_ANIM.getId())
/* 130 */       buf.writeFloat(this.keyframeInfo); 
/* 131 */     if (this.event == EnumIAnimatedEvent.STOP_START_ANIM.getId()) {
/* 132 */       buf.writeShort(this.optAnimId);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static abstract class IAnimatedEventHandler
/*     */   {
/*     */     public boolean onMessage(IAnimatedEventMessage message, MessageContext ctx) {
/* 156 */       if (message.hasEntity) {
/* 157 */         Entity e = getEntityByUUID(ctx, message.most, message.least);
/* 158 */         if (!(e instanceof IAnimated)) {
/* 159 */           CraftStudioApi.getLogger().debug("Networking error : invalid entity.");
/* 160 */           return false;
/*     */         } 
/* 162 */         message.animated = (IAnimated)e;
/*     */       } else {
/*     */         
/* 165 */         TileEntity te = getTileEntityByPos(ctx, message.x, message.y, message.z);
/* 166 */         if (!(te instanceof IAnimated)) {
/* 167 */           CraftStudioApi.getLogger().debug("Networking error : invalid tile entity.");
/* 168 */           return false;
/*     */         } 
/* 170 */         message.animated = (IAnimated)te;
/*     */       } 
/* 172 */       return true;
/*     */     }
/*     */     
/*     */     public abstract Entity getEntityByUUID(MessageContext param1MessageContext, long param1Long1, long param1Long2);
/*     */     
/*     */     public abstract TileEntity getTileEntityByPos(MessageContext param1MessageContext, int param1Int1, int param1Int2, int param1Int3);
/*     */   }
/*     */ }


/* Location:              C:\Users\Josep\Downloads\tektopia-1.1.0-deobf.jar!\META-INF\libraries\CraftStudio-1.0.0.93-mc1.12-alpha.jar!\com\leviathanstudio\craftstudio\common\network\IAnimatedEventMessage.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */