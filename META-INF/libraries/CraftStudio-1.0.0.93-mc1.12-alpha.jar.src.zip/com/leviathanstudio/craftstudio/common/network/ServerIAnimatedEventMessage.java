/*    */ package com.leviathanstudio.craftstudio.common.network;
/*    */ 
/*    */ import com.leviathanstudio.craftstudio.common.animation.AnimationHandler;
/*    */ import com.leviathanstudio.craftstudio.common.animation.IAnimated;
/*    */ import java.util.UUID;
/*    */ import net.minecraft.entity.Entity;
/*    */ import net.minecraft.tileentity.TileEntity;
/*    */ import net.minecraft.util.math.BlockPos;
/*    */ import net.minecraftforge.fml.common.network.simpleimpl.IMessage;
/*    */ import net.minecraftforge.fml.common.network.simpleimpl.IMessageHandler;
/*    */ import net.minecraftforge.fml.common.network.simpleimpl.MessageContext;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ServerIAnimatedEventMessage
/*    */   extends IAnimatedEventMessage
/*    */ {
/*    */   public ServerIAnimatedEventMessage() {}
/*    */   
/*    */   public ServerIAnimatedEventMessage(EnumIAnimatedEvent event, IAnimated animated, short animId) {
/* 28 */     super(event, animated, animId);
/*    */   }
/*    */ 
/*    */   
/*    */   public ServerIAnimatedEventMessage(EnumIAnimatedEvent event, IAnimated animated, short animId, float keyframeInfo) {
/* 33 */     super(event, animated, animId, keyframeInfo);
/*    */   }
/*    */ 
/*    */   
/*    */   public ServerIAnimatedEventMessage(EnumIAnimatedEvent event, IAnimated animated, short animId, float keyframeInfo, short optAnimId) {
/* 38 */     super(event, animated, animId, keyframeInfo, optAnimId);
/*    */   }
/*    */ 
/*    */   
/*    */   public ServerIAnimatedEventMessage(IAnimatedEventMessage eventObj) {
/* 43 */     super(eventObj);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static class ServerIAnimatedEventHandler
/*    */     extends IAnimatedEventMessage.IAnimatedEventHandler
/*    */     implements IMessageHandler<ServerIAnimatedEventMessage, ClientIAnimatedEventMessage>
/*    */   {
/*    */     public ClientIAnimatedEventMessage onMessage(ServerIAnimatedEventMessage message, MessageContext ctx) {
/* 58 */       if (!onMessage(message, ctx)) {
/* 59 */         return null;
/*    */       }
/* 61 */       message.animated.getAnimationHandler();
/* 62 */       boolean succes = AnimationHandler.onServerIAnimatedEvent(message);
/* 63 */       if (succes && message.event != EnumIAnimatedEvent.ANSWER_START_ANIM.getId())
/* 64 */         return new ClientIAnimatedEventMessage(message); 
/* 65 */       return null;
/*    */     }
/*    */ 
/*    */     
/*    */     public Entity getEntityByUUID(MessageContext ctx, long most, long least) {
/* 70 */       UUID uuid = new UUID(most, least);
/* 71 */       for (Entity e : (ctx.getServerHandler()).field_147369_b.field_70170_p.field_72996_f) {
/* 72 */         if (e.getPersistentID().equals(uuid))
/* 73 */           return e; 
/* 74 */       }  return null;
/*    */     }
/*    */ 
/*    */     
/*    */     public TileEntity getTileEntityByPos(MessageContext ctx, int x, int y, int z) {
/* 79 */       BlockPos pos = new BlockPos(x, y, z);
/* 80 */       return (ctx.getServerHandler()).field_147369_b.field_70170_p.func_175625_s(pos);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\Josep\Downloads\tektopia-1.1.0-deobf.jar!\META-INF\libraries\CraftStudio-1.0.0.93-mc1.12-alpha.jar!\com\leviathanstudio\craftstudio\common\network\ServerIAnimatedEventMessage.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */