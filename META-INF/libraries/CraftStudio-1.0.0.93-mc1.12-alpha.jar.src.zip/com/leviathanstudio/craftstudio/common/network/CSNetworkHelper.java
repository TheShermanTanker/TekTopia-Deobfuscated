/*    */ package com.leviathanstudio.craftstudio.common.network;
/*    */ 
/*    */ import com.leviathanstudio.craftstudio.CraftStudioApi;
/*    */ import net.minecraftforge.fml.common.network.NetworkRegistry;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CSNetworkHelper
/*    */ {
/*    */   public static final double EVENT_RANGE = 128.0D;
/*    */   
/*    */   public static void sendIAnimatedEvent(IAnimatedEventMessage message) {
/* 32 */     if (message.animated.isWorldRemote()) {
/*    */       
/* 34 */       CraftStudioApi.NETWORK.sendToServer(new ServerIAnimatedEventMessage(message));
/*    */     }
/*    */     else {
/*    */       
/* 38 */       CraftStudioApi.NETWORK.sendToAllAround(new ClientIAnimatedEventMessage(message), new NetworkRegistry.TargetPoint(message.animated.getDimension(), message.animated
/* 39 */             .getX(), message.animated.getY(), message.animated.getZ(), 128.0D));
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\Josep\Downloads\tektopia-1.1.0-deobf.jar!\META-INF\libraries\CraftStudio-1.0.0.93-mc1.12-alpha.jar!\com\leviathanstudio\craftstudio\common\network\CSNetworkHelper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */