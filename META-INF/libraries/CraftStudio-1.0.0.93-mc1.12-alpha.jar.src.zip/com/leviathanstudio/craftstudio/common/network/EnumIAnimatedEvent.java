/*    */ package com.leviathanstudio.craftstudio.common.network;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum EnumIAnimatedEvent
/*    */ {
/* 17 */   START_ANIM((short)0),
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 22 */   ANSWER_START_ANIM((short)1),
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 27 */   STOP_ANIM((short)2),
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 32 */   STOP_START_ANIM((short)3);
/*    */ 
/*    */ 
/*    */   
/*    */   private short id;
/*    */ 
/*    */   
/*    */   public static final short ID_COUNT = 4;
/*    */ 
/*    */ 
/*    */   
/*    */   EnumIAnimatedEvent(short id) {
/* 44 */     this.id = id;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public short getId() {
/* 53 */     return this.id;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static EnumIAnimatedEvent getEvent(short id) {
/* 64 */     switch (id) {
/*    */       case 0:
/* 66 */         return START_ANIM;
/*    */       case 1:
/* 68 */         return ANSWER_START_ANIM;
/*    */       case 2:
/* 70 */         return STOP_ANIM;
/*    */       case 3:
/* 72 */         return STOP_START_ANIM;
/*    */     } 
/* 74 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\Josep\Downloads\tektopia-1.1.0-deobf.jar!\META-INF\libraries\CraftStudio-1.0.0.93-mc1.12-alpha.jar!\com\leviathanstudio\craftstudio\common\network\EnumIAnimatedEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */