/*    */ package com.leviathanstudio.craftstudio.common.network;
/*    */ 
/*    */ import com.leviathanstudio.craftstudio.client.animation.ClientAnimationHandler;
/*    */ import com.leviathanstudio.craftstudio.common.animation.IAnimated;
/*    */ import com.leviathanstudio.craftstudio.common.animation.InfoChannel;
/*    */ import java.util.UUID;
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.entity.Entity;
/*    */ import net.minecraft.tileentity.TileEntity;
/*    */ import net.minecraft.util.math.BlockPos;
/*    */ import net.minecraftforge.fml.common.network.simpleimpl.IMessage;
/*    */ import net.minecraftforge.fml.common.network.simpleimpl.IMessageHandler;
/*    */ import net.minecraftforge.fml.common.network.simpleimpl.MessageContext;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ClientIAnimatedEventMessage
/*    */   extends IAnimatedEventMessage
/*    */ {
/*    */   public ClientIAnimatedEventMessage() {}
/*    */   
/*    */   public ClientIAnimatedEventMessage(EnumIAnimatedEvent event, IAnimated animated, short animId) {
/* 30 */     super(event, animated, animId);
/*    */   }
/*    */ 
/*    */   
/*    */   public ClientIAnimatedEventMessage(EnumIAnimatedEvent event, IAnimated animated, short animId, float keyframeInfo) {
/* 35 */     super(event, animated, animId, keyframeInfo);
/*    */   }
/*    */ 
/*    */   
/*    */   public ClientIAnimatedEventMessage(EnumIAnimatedEvent event, IAnimated animated, short animId, float keyframeInfo, short optAnimId) {
/* 40 */     super(event, animated, animId, keyframeInfo, optAnimId);
/*    */   }
/*    */ 
/*    */   
/*    */   public ClientIAnimatedEventMessage(IAnimatedEventMessage eventObj) {
/* 45 */     super(eventObj);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static class ClientIAnimatedEventHandler
/*    */     extends IAnimatedEventMessage.IAnimatedEventHandler
/*    */     implements IMessageHandler<ClientIAnimatedEventMessage, ServerIAnimatedEventMessage>
/*    */   {
/*    */     public ServerIAnimatedEventMessage onMessage(ClientIAnimatedEventMessage message, MessageContext ctx) {
/* 60 */       if (!onMessage(message, ctx)) {
/* 61 */         return null;
/*    */       }
/* 63 */       boolean succes = message.animated.getAnimationHandler().onClientIAnimatedEvent(message);
/* 64 */       if (succes && message.animated.getAnimationHandler() instanceof ClientAnimationHandler && (message.event == EnumIAnimatedEvent.START_ANIM
/* 65 */         .getId() || message.event == EnumIAnimatedEvent.STOP_START_ANIM.getId())) {
/* 66 */         ClientAnimationHandler hand = (ClientAnimationHandler)message.animated.getAnimationHandler();
/* 67 */         String animName = hand.getAnimNameFromId(message.animId);
/* 68 */         InfoChannel infoC = (InfoChannel)hand.getAnimChannels().get(animName);
/* 69 */         return new ServerIAnimatedEventMessage(EnumIAnimatedEvent.ANSWER_START_ANIM, message.animated, message.animId, infoC.totalFrames);
/*    */       } 
/* 71 */       return null;
/*    */     }
/*    */ 
/*    */     
/*    */     public Entity getEntityByUUID(MessageContext ctx, long most, long least) {
/* 76 */       UUID uuid = new UUID(most, least);
/* 77 */       for (Entity e : (Minecraft.func_71410_x()).field_71441_e.field_72996_f) {
/* 78 */         if (e.getPersistentID().equals(uuid))
/* 79 */           return e; 
/* 80 */       }  return null;
/*    */     }
/*    */ 
/*    */     
/*    */     public TileEntity getTileEntityByPos(MessageContext ctx, int x, int y, int z) {
/* 85 */       BlockPos pos = new BlockPos(x, y, z);
/* 86 */       return (Minecraft.func_71410_x()).field_71441_e.func_175625_s(pos);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\Josep\Downloads\tektopia-1.1.0-deobf.jar!\META-INF\libraries\CraftStudio-1.0.0.93-mc1.12-alpha.jar!\com\leviathanstudio\craftstudio\common\network\ClientIAnimatedEventMessage.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */